#!/bin/sh
# Compila as classes Android contra stubs (confere nomes e tipos; o teste a sério é o build do GitHub).
D=$(cd "$(dirname "$0")" && pwd); O=$(mktemp -d)
javac -d "$O" $(find "$D/stubs" -name "*.java") $(find "$D/../app/src/main/java" -name "*.java") 2>&1 | grep -v JAVA_TOOL
