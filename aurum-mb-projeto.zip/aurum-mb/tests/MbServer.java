package com.vidik.aurummb;

import com.sun.net.httpserver.*;
import java.io.*;
import java.net.InetSocketAddress;
import java.util.*;
import java.util.concurrent.*;

/** Servidor de teste: põe o núcleo real por trás da interface web (Playwright). O USSD é simulado com respostas em fila. */
public class MbServer {
  static volatile long offset = 0; static final Deque<String> script = new ConcurrentLinkedDeque<>();
  static final List<String> sentCodes = new CopyOnWriteArrayList<>(), events = new CopyOnWriteArrayList<>();
  static long now() { return System.currentTimeMillis() + offset; }
  public static void main(String[] a) throws Exception {
    final Map<String, String> m = new ConcurrentHashMap<>();
    final ScheduledExecutorService ex = Executors.newScheduledThreadPool(2);
    final MbEngine[] eng = new MbEngine[1];
    MbEngine.Ussd u = (slot, code, cb) -> { sentCodes.add(slot + ":" + code); String r = script.poll(); if (r == null) r = "ok";
      final String rr = r; ex.schedule(() -> { switch (rr) { case "fail": cb.done(1, "a operadora não aceitou o código (erro -1)"); break; case "unknown": cb.done(0, "Obrigado."); break; case "nobal": cb.done(0, "Saldo insuficiente"); break; case "erro": cb.done(0, "Erro: operadora indisponivel"); break; default: cb.done(0, "Transferencia efectuada com sucesso"); } }, 400, TimeUnit.MILLISECONDS); };
    eng[0] = new MbEngine(new MbEngine.KV() { public String get(String k, String d) { return m.getOrDefault(k, d); } public void set(String k, String v) { m.put(k, v); } }, u, new MbEngine.Out() { public boolean aurum(String t, String j) { events.add(t); return true; } public void changed() { } });
    eng[0].time = MbServer::now;
    ex.scheduleAtFixedRate(() -> { try { eng[0].tick(now()); } catch (Throwable e) { e.printStackTrace(); } }, 500, 500, TimeUnit.MILLISECONDS);
    HttpServer s = HttpServer.create(new InetSocketAddress("127.0.0.1", Integer.parseInt(a[0])), 0);
    s.createContext("/mb", h -> {
      String body = new String(h.getRequestBody().readAllBytes(), "UTF-8"); int i = body.indexOf('\n'); String op = i < 0 ? body : body.substring(0, i), arg = i < 0 ? "" : body.substring(i + 1);
      String[] f = arg.split("\u0001", -1); MbEngine e = eng[0]; long t = now(); String r;
      switch (op) {
        case "st": r = e.state(t); break;
        case "link": r = e.link(f[0], "Tecno Spark 10", t); break;
        case "unlink": e.unlink(t); r = ""; break;
        case "set": { boolean v = f[1].equals("1"); if (f[0].equals("on")) e.setOn(v); else if (f[0].equals("cf")) e.setCf(v); else e.setSc(v); r = ""; break; }
        case "sim.save": e.saveSim(Codec.i(f[0], 1), f[1], Codec.l(f[2], 0), f[3], f[4], f[5], t); r = ""; break;
        case "sim.st": e.setSimState(Codec.i(f[0], 1), f[1], t); r = ""; break;
        case "price.save": { String[][] rows = new String[20][]; for (int k = 0; k < 20; k++) rows[k] = new String[]{"", "", ""}; if (!f[0].isEmpty()) { String[] rs = f[0].split(";", -1); for (int k = 0; k < rs.length && k < 20; k++) { String[] c = rs[k].split(",", -1); for (int q = 0; q < 3 && q < c.length; q++) rows[k][q] = c[q]; } } List<String> bad = e.savePrices(rows, t); r = bad.isEmpty() ? "" : "ERR:" + bad.size() + " linhas com erro. Veja o Painel de erros."; break; }
        case "tel.add": r = e.addTel(f[0], t); break;
        case "tel.tog": e.toggleTel(f[0]); r = ""; break;
        case "redeem": r = e.redeem(f[0], t); break;
        case "order.edit": r = e.editOrder(f[0], f[1], Codec.l(f[2], 0), t); break;
        case "order.cancel": r = e.cancelOrder(f[0], t); break;
        case "order.done": r = e.markDone(f[0], t); break;
        case "order.reg": r = e.register(f[0], Codec.l(f[1], 0), Codec.l(f[2], 0), false, t); break;
        case "sim.ussdc": e.setCredUssd(Codec.i(f[0], 1), f[1], t); r = ""; break;
        case "order.manual": r = e.submit("M" + t, f[0], Codec.l(f[1], 0), Codec.l(f[2], 0), false, t); break;
        case "order.ok": e.confirmOrder(f[0], f[1].equals("1"), t); r = ""; break;
        case "err.clear": e.clearErrs(); r = ""; break;
        case "perms": r = "{\"call\":true,\"phone\":true,\"battery\":true,\"acc\":true,\"aurum\":false}"; break;
        case "simsinfo": r = "[{\"slot\":0,\"name\":\"Vodacom\"},{\"slot\":1,\"name\":\"Movitel\"}]"; break;
        case "copy": r = ""; break;
        case "acc": r = ""; break;
        // só para o teste
        case "t.script": script.clear(); for (String x : f) if (!x.isEmpty()) script.add(x); r = ""; break;
        case "t.ack": r = String.valueOf(e.linkAck(f[0], f[1].equals("1"), f[2], t)); break;
        case "t.skip": offset += Long.parseLong(f[0]); r = ""; break;
        case "t.sent": r = String.join(",", sentCodes); break;
        case "t.events": r = String.join(",", events); break;
        default: r = "ERR:operação desconhecida";
      }
      byte[] o = r.getBytes("UTF-8"); h.getResponseHeaders().add("Content-Type", "text/plain; charset=utf-8"); h.getResponseHeaders().add("Access-Control-Allow-Origin", "*"); h.sendResponseHeaders(200, o.length); h.getResponseBody().write(o); h.close();
    });
    s.start(); System.out.println("pronto");
  }
}
