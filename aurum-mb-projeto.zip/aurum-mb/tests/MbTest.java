package com.vidik.aurummb;

import java.util.*;

public class MbTest {
  static int ok, bad;
  static void t(String n, boolean c) { if (c) ok++; else { bad++; System.out.println("FALHOU: " + n); } }

  static class Fake implements MbEngine.Ussd {
    List<String> sent = new ArrayList<>(); List<Integer> slots = new ArrayList<>(); Deque<Object[]> script = new ArrayDeque<>(); MbEngine.Cb last;
    public void send(int slot, String code, MbEngine.Cb cb) {
      sent.add(code); slots.add(slot); Object[] r = script.poll();
      if (r == null) r = new Object[]{0, "Transferencia efectuada com sucesso"};
      cb.done((Integer) r[0], (String) r[1]);
    }
  }
  static class Mem implements MbEngine.KV { Map<String, String> m = new HashMap<>(); public String get(String k, String d) { return m.getOrDefault(k, d); } public void set(String k, String v) { m.put(k, v); } }
  static class Sink implements MbEngine.Out { List<String> ev = new ArrayList<>(); boolean deliver = true; public boolean aurum(String ty, String j) { ev.add(ty); return deliver; } public void changed() { } }

  static final long T0 = 1_700_000_000_000L; static long now = T0;
  static MbEngine mk(Mem kv, Fake f, Sink s) { MbEngine e = new MbEngine(kv, f, s); e.time = () -> now; return e; }
  static void setup(MbEngine e) {
    e.link("MB-ABCD-EFGH", "Tecno", now); e.linkAck("MB-ABCD-EFGH", true, "", now);
    String[][] r = new String[20][]; for (int i = 0; i < 20; i++) r[i] = new String[]{"", "", ""};
    r[0] = new String[]{"100", "1000", "15"}; r[1] = new String[]{"50", "500", "8"}; e.savePrices(r, now);
    e.saveSim(1, "Vodacom", 20000, "lib", "*123*{NUM}*{MB}#", "", now); e.saveSim(2, "Movitel", 20000, "lib", "*456*{NUM}*{MB}#", "", now);
    e.redeem(MbCode.make("PCT", 7, new Random(1)), now);
  }
  static void pump(MbEngine e, int times) { for (int i = 0; i < times; i++) { now += 1000; e.tick(now); } }

  public static void main(String[] a) {
    // códigos
    Random r = new Random(5);
    String c7 = MbCode.make("PCT", 7, r), c62 = MbCode.make("PCT", 62, r), lg = MbCode.make("LUG", 10, r);
    t("codigo pacote valido", MbCode.parse(c7) != null && MbCode.parse(c7)[1].equals("7"));
    t("codigo lugares valido", MbCode.parse(lg) != null && MbCode.parse(lg)[0].equals("LUG"));
    t("codigo inventado", MbCode.parse("PCT-7-AAAAAA-ZZZZ") == null);
    t("dias invalidos", MbCode.parse("PCT-10-AAAAAA-" + MbCode.sign("PCT", 10, "AAAAAA")) == null);
    t("codigo do python", MbCode.parse("PCT-7-W49CHU-6KXS") != null);
    { MbEngine q = new MbEngine(new MbEngine.KV() { java.util.Map<String,String> m = new java.util.HashMap<>(); public String get(String k, String d) { return m.getOrDefault(k, d); } public void set(String k, String v) { m.put(k, v); } }, (sl, cd, cb) -> { }, new MbEngine.Out() { public boolean aurum(String ty, String js) { return true; } public void changed() { } });
      q.link("MB-QQQQ-WWWW", "X", now); t("sem ack nao fica ligada (codigo inventado)", !q.linked() && q.pending());
      t("ack de outro codigo ignorado", !q.linkAck("MB-AAAA-BBBB", true, "", now) && !q.linked());
      q.linkAck("MB-QQQQ-WWWW", false, "Código não existe", now); t("recusada pela Aurum", !q.linked() && !q.pending() && q.state(now).contains("Código não existe"));
      q.link("MB-QQQQ-WWWW", "X", now); q.linkTimeout(now + 50000); t("Aurum nao responde: erro", !q.linked() && q.state(now + 50000).contains("não respondeu"));
      q.link("MB-QQQQ-WWWW", "X", now); t("ack certo liga", q.linkAck("mb-qqqq-wwww", true, "", now) && q.linked() && q.status(now, "{\"acc\":true}").contains("\"type\":\"STATUS\"") && q.status(now, "").contains("\"android\":{}")); }
    t("ligacao formato", MbCode.linkFormat("mb-abcd-efgh") && !MbCode.linkFormat("MB-ABC-EFGH") && !MbCode.linkFormat("WA-ABCD-EFGH"));

    // arranque: sem pacote = bloqueada
    Mem kv = new Mem(); Fake f = new Fake(); Sink sk = new Sink(); MbEngine e = mk(kv, f, sk);
    t("nova app bloqueada", e.blocked(now));
    e.link("MB-ABCD-EFGH", "Tecno", now); e.linkAck("MB-ABCD-EFGH", true, "", now);
    String[][] rows = new String[20][]; for (int i = 0; i < 20; i++) rows[i] = new String[]{"", "", ""};
    rows[0] = new String[]{"100", "1000", "15"}; e.savePrices(rows, now);
    e.saveSim(1, "Vodacom", 20000, "lib", "*123*{NUM}*{MB}#", "", now);
    t("pedido recusado sem pacote", e.submit("P0", "841234567", 1000, 100, true, now).startsWith("ERR"));
    t("erro Pacote registado", e.errs.get(0).src.equals("Pacote") && e.errs.get(0).code.equals("E5"));
    t("aviso REFUSED a Aurum", sk.ev.contains("REFUSED"));
    t("codigo invalido nao ativa", e.redeem("PCT-7-AAAAAA-ZZZZ", now).startsWith("ERR"));
    t("ativa 7 dias", e.redeem(c7, now).isEmpty() && !e.blocked(now) && e.left(now) == 7 * MbEngine.DAY);
    t("codigo usado so uma vez", e.redeem(c7, now).startsWith("ERR:Este"));
    e.redeem(MbCode.make("PCT", 15, r), now); t("soma dias", e.left(now) == 22 * MbEngine.DAY);
    now += 8 * MbEngine.DAY; t("passa o tempo", !e.blocked(now));
    now = T0;

    // relogio nao recua
    MbEngine e2 = mk(new Mem(), new Fake(), new Sink()); e2.redeem(c7, now); now += 8 * MbEngine.DAY; t("expirou", e2.blocked(now)); long back = T0; t("recuar o relogio nao devolve dias", e2.blocked(back)); now = T0;

    // fluxo normal
    kv = new Mem(); f = new Fake(); sk = new Sink(); e = mk(kv, f, sk); setup(e);
    t("pedido aceite", e.submit("A1", "258841234567", 1000, 100, true, now).isEmpty());
    t("repetido nao duplica", e.submit("A1", "841234567", 1000, 100, true, now).isEmpty() && e.orders.size() == 1);
    t("fora da tabela", e.submit("A2", "841234567", 999, 100, true, now).startsWith("ERR") && e.errs.get(0).src.equals("Tabela"));
    t("numero invalido", e.submit("A3", "12345", 1000, 100, true, now).startsWith("ERR"));
    pump(e, 2);
    t("USSD montado", f.sent.size() == 1 && f.sent.get(0).equals("*123*841234567*1000#"));
    t("entregue", e.find("A1").state.equals("ok") && e.sims[0].mb == 19000 && e.sims[0].tries == 1);
    t("RESULT enviado a Aurum", sk.ev.contains("RESULT"));
    t("lucro somado", e.profit == 15);
    t("cliente guardado", e.tels.size() == 1 && e.tels.get(0).n.equals("841234567"));
    t("numero bloqueado recusa", e.addTel("841234567", now).startsWith("ERR") && !e.tels.isEmpty());
    e.toggleTel("841234567"); t("bloqueado", e.submit("A4", "841234567", 1000, 100, true, now).startsWith("ERR:Número bloqueado"));
    e.toggleTel("841234567");

    // falha: insiste ate enviar
    f.script.add(new Object[]{0, "Erro: operadora indisponivel"}); f.script.add(new Object[]{1, "sem sinal"});
    e.submit("B1", "841111111", 500, 50, true, now); pump(e, 1);
    t("1a falha", e.find("B1").state.equals("fila") && e.find("B1").att == 1);
    pump(e, 7); t("2a falha", e.find("B1").att == 2);
    pump(e, 15); t("insistiu e entregou", e.find("B1").state.equals("ok") && e.find("B1").att == 3);
    t("erros USSD com opcao", e.errs.stream().anyMatch(x -> x.src.equals("USSD") && x.opt.contains("cartão 1") && x.msg.contains("Insisto")));

    // .tentar: desiste depois de N tentativas
    e.setRetries(2); f.script.add(new Object[]{1, "sem sinal"}); f.script.add(new Object[]{1, "sem sinal"}); f.script.add(new Object[]{1, "sem sinal"});
    e.submit("R1", "841111112", 500, 50, true, now); pump(e, 25);
    t(".tentar 2: desiste", e.find("R1").state.equals("rec") && e.find("R1").att == 2 && sk.ev.stream().anyMatch(x -> x.equals("REFUSED")));
    t("estado leva retries e megas", e.status(now, "{}").contains("\"retries\":2") && e.status(now, "{}").contains("\"mb\":"));
    e.setRetries(0); f.script.clear();

    // resposta duvidosa nao repete
    f.script.add(new Object[]{0, "Obrigado."}); e.submit("C1", "842222222", 500, 50, false, now); pump(e, 2);
    t("duvidosa fica a confirmar", e.find("C1").state.equals("chk")); int n0 = f.sent.size(); pump(e, 30); t("nao repete sozinha", f.sent.size() == n0);
    e.confirmOrder("C1", true, now); t("confirmada", e.find("C1").state.equals("ok"));

    // rotacao: 10 transferencias no cartao 1, depois cartao 2
    kv = new Mem(); f = new Fake(); sk = new Sink(); e = mk(kv, f, sk); setup(e);
    for (int i = 0; i < 12; i++) e.submit("R" + i, "8400" + (10000 + i), 500, 50, false, now);
    pump(e, 30);
    int s1 = 0, s2 = 0; for (int sl : f.slots) if (sl == 0) s1++; else s2++;
    t("10 no cartao 1", s1 == 10); t("resto no cartao 2", s2 == 2);
    t("cartao 1 esgotado", e.sims[0].st.equals("esg") && e.sims[0].tries == 10); t("em uso cartao 2", e.cur == 1);

    // cartao acaba cedo
    kv = new Mem(); f = new Fake(); sk = new Sink(); e = mk(kv, f, sk); setup(e); e.saveSim(1, "Vodacom", 300, "lib", "*123*{NUM}*{MB}#", "", now);
    e.submit("S1", "841230000", 1000, 100, false, now); pump(e, 3);
    t("sem megas troca de cartao", f.slots.get(0) == 1 && e.sims[0].st.equals("esg"));

    // saldo insuficiente na resposta
    kv = new Mem(); f = new Fake(); sk = new Sink(); e = mk(kv, f, sk); setup(e);
    f.script.add(new Object[]{0, "Saldo insuficiente"}); e.submit("I1", "841230001", 1000, 100, false, now); pump(e, 4);
    t("saldo insuficiente passa ao cartao 2", e.sims[0].st.equals("esg") && e.find("I1").state.equals("ok") && e.find("I1").sim == 2);

    // os dois esgotados
    kv = new Mem(); f = new Fake(); sk = new Sink(); e = mk(kv, f, sk); setup(e);
    e.setSimState(1, "esg", now); e.setSimState(2, "esg", now);
    e.submit("W1", "841230002", 1000, 100, true, now); pump(e, 2);
    t("em espera", e.find("W1").state.equals("esp") && f.sent.isEmpty());
    t("avisa a Aurum uma vez", sk.ev.stream().filter(x -> x.equals("WAIT")).count() == 1); pump(e, 5); t("nao repete o aviso", sk.ev.stream().filter(x -> x.equals("WAIT")).count() == 1);
    e.setSimState(1, "lib", now); t("RESUME", sk.ev.contains("RESUME")); pump(e, 3);
    t("ADM liberou: so cartao 1", f.slots.size() == 1 && f.slots.get(0) == 0 && e.find("W1").state.equals("ok"));

    // sem codigo USSD
    kv = new Mem(); f = new Fake(); sk = new Sink(); e = mk(kv, f, sk); setup(e); e.saveSim(1, "Movitel", 20000, "lib", "", "", now); e.saveSim(2, "Movitel", 20000, "esg", "", "", now);
    e.submit("U1", "841230003", 1000, 100, false, now); pump(e, 2);
    t("sem USSD pede para definir", e.find("U1").state.equals("ok"));   // só Vodacom: usa o código padrão
    e.saveSim(1, "Vodacom", 20000, "lib", "", "", now); e.setCredUssd(1, "", now); e.saveCredPrices(new String[][]{{"50","60","5"}}, now);
    t("credito sem USSD aceite", e.submit("C0", "841230009", 60, 50, false, true, now).isEmpty()); pump(e, 2); t("credito: usa codigo *111# do video", e.find("C0").state.equals("ok") && f.sent.toString().contains("*111#"));
    e.setCredUssd(1, "*999*{NUM}*{VAL}#", now); pump(e, 3);
    t("credito fora da tabela recusado", !e.submit("C1", "841230009", 70, 50, false, true, now).isEmpty() || e.find("C1") == null || !e.find("C1").state.equals("fila"));
    // credito: estado proprio e 20 lugares
    e.setCredState(1, "esg", now); boolean c9 = e.submit("C9", "841230009", 60, 50, false, true, now).isEmpty(); boolean m9 = e.submit("M9", "841230009", 1000, 100, false, now).isEmpty(); pump(e, 4);
    t("credito esgotado nao envia mas megas sim", c9 && m9 && !e.find("C9").state.equals("ok") && e.find("M9").state.equals("ok"));
    e.setCredState(1, "lib", now); pump(e, 3); t("credito liberado volta a enviar", e.find("C9").state.equals("ok"));
    String[][] cr = new String[20][]; for (int i = 0; i < 20; i++) cr[i] = new String[]{"" + (10 + i), "" + (12 + i), "1"};
    e.saveCredPrices(cr, now); t("credito: so 10 lugares sem desbloqueio", e.cpriceFor(10, 12) != null && e.cpriceFor(25, 27) == null);
    e.saveCredPrices(new String[][]{{"50","60","5"}}, now);
    t("codigo de teste de 3 dias vale", MbCode.parse(MbCode.make("PCT", 3, new java.util.Random(5))) != null && MbCode.parse("PCT-4-AAAAAA-AAAA") == null);
    t("USSD: 'em execucao' e espera", UssdText.loading("Código USSD em execução…", false) && UssdText.loading("USSD code running...", false) && UssdText.loading("A executar código USSD", false));
    t("USSD: menu nao e espera", !UssdText.loading("1. WFTTI+\n2. Por Hora\n3. Diario\n8. Servicos de Internet\n0)Voltar", false) && !UssdText.loading("Código USSD em execução…", true) && !UssdText.loading("Transferência efetuada com sucesso para 841230009. Obrigado por usar os nossos serviços e até breve.", false));
    t("USSD: pacotes do telefone", UssdText.known("com.android.phone") && UssdText.known("com.huawei.phone") && UssdText.known("com.samsung.android.dialer") && !UssdText.known("com.google.android.inputmethod.latin") && !UssdText.known("com.vidik.aurummb"));
    t("so Vodacom: 86 recusado", e.submit("V86", "861230009", 60, 50, false, true, now).startsWith("ERR"));
    e.setCredUssd(1, "*999*{VAL}#", now); e.submit("G1", "841230077", 60, 50, false, true, now); pump(e, 3);
    t("USSD sem {NUM} nunca marca", e.find("G1").state.equals("rec") && !f.sent.toString().contains("*999*60#"));
    t("guarda: certo", MbEngine.guard("*162#|8|2|{MB}|{NUM}", "*162#|8|2|1500|841230009", "841230009", 1500).isEmpty() && !MbEngine.guard("*162#|8|2|{MB}|{NUM}", "*162#|8|2|1500|841230009", "861230009", 1500).isEmpty());
    e.setCredUssd(1, "", now);
    t("cancelar pedido", e.submit("C2", "841230009", 60, 50, false, true, now).isEmpty() && e.cancelOrder("C2", now).isEmpty() && e.find("C2").state.equals("can"));
    t("editar numero", e.submit("C3", "841230009", 60, 50, false, true, now).isEmpty() && e.editOrder("C3", "84 123 0010", 60, now).isEmpty() && e.find("C3").phone.equals("841230010"));
    t("marcar entregue", e.markDone("C3", now).isEmpty() && e.find("C3").state.equals("ok") && e.markDone("C3", now).startsWith("ERR"));
    t("registar a mao", e.register("841230011", 60, 50, true, now).isEmpty() && e.orders.get(0).state.equals("ok"));
    e.saveSim(1, "Vodacom", 20000, "lib", "*123*{NUM}*{MB}#", "", now); pump(e, 3); t("definido: entrega", e.find("U1").state.equals("ok"));

    // Vodacom sem codigo escrito usa a sequencia padrao; os passos separam-se com |
    kv = new Mem(); f = new Fake(); sk = new Sink(); e = mk(kv, f, sk); setup(e); e.saveSim(1, "Vodacom", 20000, "lib", "", "", now); e.saveSim(2, "Movitel", 20000, "esg", "x", "", now);
    e.submit("V1", "841230010", 1000, 100, false, now); pump(e, 2);
    t("Vodacom: sequencia padrao", f.sent.size() == 1 && f.sent.get(0).equals("*162#|8|2|1000|841230010"));

    // numero invalido na operadora: recusa e nao repete
    f.script.add(new Object[]{0, "You have entered an invalid number. Enter recipient number:"}); e.submit("V2", "841230011", 1000, 100, false, now); pump(e, 3); int nn = f.sent.size(); pump(e, 30);
    t("numero invalido: recusado", e.find("V2").state.equals("rec") && sk.ev.contains("REFUSED") && f.sent.size() == nn);

    // "nao permitida" (sem megas/limite): passa ao outro cartao
    kv = new Mem(); f = new Fake(); sk = new Sink(); e = mk(kv, f, sk); setup(e);
    f.script.add(new Object[]{0, "Tranferencia de megas nao permitida. Apos a transferencia de megas tens que ficar com um minimo de 0 MB. Obrigado"}); e.submit("N1", "841230012", 1000, 100, false, now); pump(e, 4);
    t("nao permitida: troca de cartao", e.sims[0].st.equals("esg") && e.find("N1").state.equals("ok") && e.find("N1").sim == 2);

    // limite de 10 por dia: 24 h depois o cartao volta
    kv = new Mem(); f = new Fake(); sk = new Sink(); e = mk(kv, f, sk); setup(e); e.saveSim(2, "Movitel", 20000, "esg", "*456*{NUM}*{MB}#", "", now);
    for (int i = 0; i < 10; i++) e.submit("D" + i, "8412300" + (20 + i), 500, 50, false, now); pump(e, 30);
    t("10 feitas: cartao 1 parado pelo limite", e.sims[0].st.equals("esg") && e.sims[0].lim && e.sims[0].tries == 10);
    e.submit("D99", "841230099", 500, 50, false, now); pump(e, 3); t("11.a espera", e.find("D99").state.equals("esp"));
    now += MbEngine.DAY + 5000; pump(e, 4);
    t("24 h depois: volta a servir", e.sims[0].st.equals("lib") && e.sims[0].tries <= 1 && e.find("D99").state.equals("ok")); now = T0;

    // pacote acaba com pedidos na fila
    kv = new Mem(); f = new Fake(); sk = new Sink(); e = mk(kv, f, sk); setup(e);
    e.submit("X1", "841230004", 1000, 100, false, now); now += 8 * MbEngine.DAY; e.tick(now);
    t("pacote acabou: pedido espera", e.find("X1").state.equals("esp") && sk.ev.contains("BLOCKED") && e.state(now).contains("\"blocked\":true"));
    t("pedido novo recusado", e.submit("X2", "841230005", 1000, 100, false, now).startsWith("ERR"));
    e.redeem(MbCode.make("PCT", 7, r), now); pump(e, 3); t("pagou: retoma e entrega", e.find("X1").state.equals("ok")); now = T0;

    // lugares
    e.savePrices(rows, now); t("10 lugares", e.slots == 10);
    String[][] rr = new String[20][]; for (int i = 0; i < 20; i++) rr[i] = new String[]{"", "", ""}; rr[12] = new String[]{"70", "700", "9"};
    e.savePrices(rr, now); t("linha 13 bloqueada e ignorada", e.prices[12][0].isEmpty());
    t("desbloqueia +10", e.redeem(lg, now).isEmpty() && e.slots == 20);
    t("nao passa de 20", e.redeem(MbCode.make("LUG", 10, r), now).startsWith("ERR:Já tem"));
    e.savePrices(rr, now); t("linha 13 guardada", e.prices[12][0].equals("70"));
    rr[3] = new String[]{"20", "", ""}; List<String> bad2 = e.savePrices(rr, now); t("linha incompleta", bad2.size() == 1 && e.errs.get(0).src.equals("Tabela"));

    // aviso nao entregue
    sk.deliver = false; e.unlink(now); t("aviso falhado vira erro Rede", e.errs.stream().anyMatch(x -> x.src.equals("Rede")));

    // persistencia
    kv = new Mem(); f = new Fake(); sk = new Sink(); e = mk(kv, f, sk); setup(e); f.script.add(new Object[]{0, "Erro"});
    e.submit("Z1", "841230006", 1000, 100, true, now); pump(e, 1);
    MbEngine g = mk(kv, new Fake(), new Sink());
    t("persistencia: link/pacote/sims", g.linked() && !g.blocked(now) && g.sims[0].ussd.equals("*123*{NUM}*{MB}#") && g.sims[1].op.equals("Vodacom"));
    t("persistencia: pedido e erros", g.find("Z1") != null && g.find("Z1").state.equals("fila") && !g.errs.isEmpty());
    t("persistencia: codigo usado", g.redeem(MbCode.make("PCT", 7, new Random(1)), now).startsWith("ERR:Este"));
    e.find("Z1").state = "env"; e.save(); MbEngine h = mk(kv, new Fake(), new Sink()); t("envio interrompido vira confirmar", h.find("Z1").state.equals("chk"));
    // estado JSON
    String js = e.state(now); t("estado JSON", js.startsWith("{") && js.endsWith("}") && js.contains("\"sims\":[") && js.contains("\"errs\":["));
    t("codigo da Aurum", g.codeOk("mb-abcd-efgh") && !g.codeOk("MB-AAAA-BBBB"));
    // pagamento por e-Mola: o selo e a caixa de resposta têm de dar IGUAL na Aurum do dono (mesmos valores nos dois testes)
    t("norm do ID", MbCode.norm("PP261027.1029.H97116").equals("PP2610271029H97116") && MbCode.norm(" pp261027.1029.h97116 ").equals("PP2610271029H97116"));
    t("ID aceito", MbCode.idOk("PP2610271029H97116") && !MbCode.idOk("PP26") && !MbCode.idOk("1234567890123") && !MbCode.idOk("ABCDEFGHIJKLMN"));
    t("selo do ID", MbCode.payHash("PP261027.1029.H97116").equals("db310e4b7be3f70fa3d8") && MbCode.payHash("pp261027.1029.h97116").equals("db310e4b7be3f70fa3d8"));
    t("caixa de resposta", MbCode.payReply("PP261027.1029.H97116").equals("MB-9XS9-5DWT") && MbCode.linkFormat(MbCode.payReply("PP261027.1029.H97116")) && MbCode.linkFormat("MB-PAGA-DESK"));
    t("ID diferente, caixa diferente", !MbCode.payReply("PP261027.1029.H97117").equals(MbCode.payReply("PP261027.1029.H97116")));
    t("precos novos", MbCode.price(5) == 49 && MbCode.price(13) == 99 && MbCode.price(22) == 139 && MbCode.price(32) == 179 && MbCode.price(64) == 299 && MbCode.price(7) < 0);
    t("codigos antigos continuam", MbCode.validDays(7) && MbCode.validDays(15) && MbCode.validDays(25) && MbCode.validDays(62) && MbCode.validDays(3) && MbCode.validDays(5) && MbCode.validDays(64) && !MbCode.validDays(9));
    String cn = MbCode.make("PCT", 13, new java.util.Random(5)); t("codigo novo de 13 dias", MbCode.parse(cn) != null && MbCode.parse(cn)[1].equals("13"));
    System.out.println(ok + " certos, " + bad + " falhados"); if (bad > 0) System.exit(1);
  }
}
