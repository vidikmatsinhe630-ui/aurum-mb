#!/bin/sh
# Testa o núcleo da Aurum MB (só precisa de Java).
D=$(cd "$(dirname "$0")" && pwd); SRC="$D/../app/src/main/java/com/vidik/aurummb"; O=$(mktemp -d)
javac -d "$O" "$SRC/Codec.java" "$SRC/MbCode.java" "$SRC/MbEngine.java" "$D/MbTest.java" || exit 1
java -cp "$O" com.vidik.aurummb.MbTest
