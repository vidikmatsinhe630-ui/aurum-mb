package android.app;
public class NotificationChannel { public NotificationChannel(String id,CharSequence n,int imp){} }
