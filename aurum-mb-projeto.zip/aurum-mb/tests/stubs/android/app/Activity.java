package android.app;
public class Activity extends android.content.Context { public void setContentView(android.view.View v){} public void runOnUiThread(Runnable r){} public android.view.Window getWindow(){return null;}
 protected void onCreate(android.os.Bundle b){} protected void onResume(){} protected void onPause(){} public void requestPermissions(String[] p,int c){}
 public void onRequestPermissionsResult(int r,String[] p,int[] g){} public android.content.Context getApplicationContext(){return null;} public android.content.SharedPreferences getSharedPreferences(String n,int m){return null;}
 public android.content.pm.PackageManager getPackageManager(){return null;} public Object getSystemService(String n){return null;} public int checkSelfPermission(String p){return 0;}
 public void sendBroadcast(android.content.Intent i,String perm){} public android.content.ComponentName startForegroundService(android.content.Intent i){return null;} public String getPackageName(){return null;} public void startActivity(android.content.Intent i){} }
