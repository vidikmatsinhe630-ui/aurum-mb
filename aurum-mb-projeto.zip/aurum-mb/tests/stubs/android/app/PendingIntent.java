package android.app;
public class PendingIntent { public static final int FLAG_IMMUTABLE=1; public static PendingIntent getActivity(android.content.Context c,int r,android.content.Intent i,int f){return null;} }
