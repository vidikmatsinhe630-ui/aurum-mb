package android.view;
public class Window { public void addFlags(int f){} public void clearFlags(int f){} }
