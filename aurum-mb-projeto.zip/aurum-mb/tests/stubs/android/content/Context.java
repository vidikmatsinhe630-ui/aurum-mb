package android.content;
public abstract class Context {
 public static final String TELEPHONY_SERVICE="phone",TELEPHONY_SUBSCRIPTION_SERVICE="sub",NOTIFICATION_SERVICE="n",POWER_SERVICE="p",CLIPBOARD_SERVICE="c",TELECOM_SERVICE="t";
 public abstract Context getApplicationContext(); public abstract android.content.SharedPreferences getSharedPreferences(String n,int m);
 public abstract android.content.pm.PackageManager getPackageManager(); public abstract Object getSystemService(String n); public abstract int checkSelfPermission(String p);
 public abstract void sendBroadcast(Intent i,String perm); public abstract ComponentName startForegroundService(Intent i); public abstract String getPackageName(); public ComponentName startService(Intent i){return null;}
 public abstract void startActivity(Intent i); public abstract ContentResolver getContentResolver(); }
