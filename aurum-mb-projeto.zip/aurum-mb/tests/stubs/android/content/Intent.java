package android.content;
public class Intent { public static final String ACTION_MAIN="x";
 public Intent(String a){} public static final String ACTION_CALL="a"; public static final int FLAG_ACTIVITY_NEW_TASK=1; public Intent addFlags(int f){return this;} public Intent putExtra(String k,boolean v){return this;} public Intent putExtra(String k,int v){return this;} public Intent(Context c,Class<?> k){} public Intent(String a,android.net.Uri u){}
 public Intent setPackage(String p){return this;} public Intent putExtra(String k,String v){return this;} public String getStringExtra(String k){return null;}
 public long getLongExtra(String k,long d){return d;} public boolean getBooleanExtra(String k,boolean d){return d;} }
