package android.content;
public class Intent { public static final String ACTION_MAIN="x";
 public Intent(String a){} public Intent(Context c,Class<?> k){} public Intent(String a,android.net.Uri u){}
 public Intent setPackage(String p){return this;} public Intent putExtra(String k,String v){return this;} public String getStringExtra(String k){return null;}
 public long getLongExtra(String k,long d){return d;} public boolean getBooleanExtra(String k,boolean d){return d;} }
