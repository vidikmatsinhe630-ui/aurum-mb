package android;
public final class Manifest { public static final class permission { public static final String CALL_PHONE="a",READ_PHONE_STATE="b",POST_NOTIFICATIONS="c"; } }
