package android.graphics;
public class Rect { public int left,top,right,bottom; public boolean isEmpty(){return left>=right||top>=bottom;} public int centerX(){return (left+right)/2;} public int centerY(){return (top+bottom)/2;} }
