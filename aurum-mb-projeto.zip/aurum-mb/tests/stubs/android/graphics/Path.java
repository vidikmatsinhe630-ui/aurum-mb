package android.graphics;
public class Path { public void moveTo(float x,float y){} }
