package android.os;
public class Bundle { public void putInt(String k,int v){} public void putCharSequence(String k,CharSequence v){} public void putParcelable(String k,Parcelable v){} }