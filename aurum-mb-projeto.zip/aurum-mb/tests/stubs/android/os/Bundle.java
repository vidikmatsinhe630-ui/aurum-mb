package android.os;
public class Bundle { public void putCharSequence(String k,CharSequence v){} public void putParcelable(String k,Parcelable v){} }