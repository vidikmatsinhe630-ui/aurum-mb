package android.os;
public class Build { public static final String MODEL="m",MANUFACTURER="f"; public static class VERSION { public static final int SDK_INT=34; } }
