package android.os;
public class Build { public static final String MODEL="m",MANUFACTURER="f",FINGERPRINT="fp"; public static class VERSION { public static final int SDK_INT=34; } }
