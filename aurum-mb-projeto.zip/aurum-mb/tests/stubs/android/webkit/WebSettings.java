package android.webkit;
public class WebSettings { public void setJavaScriptEnabled(boolean b){} public void setDomStorageEnabled(boolean b){} public void setSupportZoom(boolean b){} public void setBuiltInZoomControls(boolean b){} }
