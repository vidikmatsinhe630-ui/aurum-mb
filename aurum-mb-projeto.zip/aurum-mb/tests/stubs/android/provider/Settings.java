package android.provider;
public class Settings { public static final String ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS="x"; }
