package android.accessibilityservice;
public abstract class AccessibilityService extends android.app.Service {
 public static final int GLOBAL_ACTION_BACK=1;
 public abstract void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent e); public abstract void onInterrupt();
 protected void onServiceConnected(){} public boolean onUnbind(android.content.Intent i){return false;}
 public android.view.accessibility.AccessibilityNodeInfo getRootInActiveWindow(){return null;} public java.util.List<android.view.accessibility.AccessibilityWindowInfo> getWindows(){return null;} public final boolean performGlobalAction(int a){return true;}
 public android.os.IBinder onBind(android.content.Intent i){return null;} }