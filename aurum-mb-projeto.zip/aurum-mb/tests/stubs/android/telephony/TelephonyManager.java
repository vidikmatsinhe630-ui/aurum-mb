package android.telephony;
public class TelephonyManager { public TelephonyManager createForSubscriptionId(int s){return this;}
 public static abstract class UssdResponseCallback { public void onReceiveUssdResponse(TelephonyManager t,String r,CharSequence c){} public void onReceiveUssdResponseFailed(TelephonyManager t,String r,int f){} }
 public void sendUssdRequest(String u,UssdResponseCallback c,android.os.Handler h){} }
