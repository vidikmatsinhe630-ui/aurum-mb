package android.telephony;
public class SubscriptionManager { public SubscriptionInfo getActiveSubscriptionInfoForSimSlotIndex(int s){return null;} public java.util.List<SubscriptionInfo> getActiveSubscriptionInfoList(){return null;} }
