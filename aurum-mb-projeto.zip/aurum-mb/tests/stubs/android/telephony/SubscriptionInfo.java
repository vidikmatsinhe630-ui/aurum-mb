package android.telephony;
public class SubscriptionInfo { public int getSubscriptionId(){return 0;} public int getSimSlotIndex(){return 0;} public CharSequence getCarrierName(){return null;} }
