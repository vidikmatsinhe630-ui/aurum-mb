package android.telecom;
public class PhoneAccountHandle implements android.os.Parcelable {}