package android.net;
public class Uri { public static Uri parse(String s){return null;} public static Uri fromParts(String a,String b,String c){return null;} }