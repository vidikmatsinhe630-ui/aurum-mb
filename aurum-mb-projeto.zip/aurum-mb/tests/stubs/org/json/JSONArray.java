package org.json;
public class JSONArray { public int length() { return 0; } public JSONObject optJSONObject(int i) { return null; } public JSONObject getJSONObject(int i) throws JSONException { throw new JSONException("stub"); } }
