package org.json;
public class JSONObject {
  public JSONObject() { } public JSONObject(String s) throws JSONException { }
  public JSONObject put(String k, Object v) throws JSONException { return this; } public JSONObject put(String k, long v) throws JSONException { return this; } public JSONObject put(String k, boolean v) throws JSONException { return this; }
  public String optString(String k) { return ""; } public String optString(String k, String d) { return d; } public long optLong(String k) { return 0; } public long optLong(String k, long d) { return d; }
  public boolean optBoolean(String k, boolean d) { return d; } public JSONArray optJSONArray(String k) { return null; } public boolean has(String k) { return false; } public int optInt(String k, int d) { return d; } public int optInt(String k) { return 0; }
}
