package com.vidik.aurummb;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
  public void onReceive(Context c, Intent i) { if (MbHub.get(c).linked()) MbService.start(c); }
}
