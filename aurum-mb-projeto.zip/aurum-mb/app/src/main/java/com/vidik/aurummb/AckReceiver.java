package com.vidik.aurummb;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Resposta da Aurum ao pedido de ligação. Só entra quem tem a permissão (mesma assinatura). A MB só fica ligada se a Aurum disser que o código existe. */
public class AckReceiver extends BroadcastReceiver {
  public void onReceive(Context c, Intent i) {
    MbEngine e = MbHub.get(c); long now = System.currentTimeMillis();
    boolean ok = e.linkAckRemote(String.valueOf(i.getStringExtra("code")), i.getBooleanExtra("ok", false), i.getStringExtra("msg"), now);
    if (ok) { MbService.start(c); MbHub.sendStatus(c, true); }
    MbHub.notifyUi();
  }
}
