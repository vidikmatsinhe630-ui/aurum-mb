package com.vidik.aurummb;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.PowerManager;

/** Permissões que funcionam do Android 5.1 (onde são dadas na instalação) ao mais recente. */
final class Perm {
  private Perm() { }
  static boolean has(Context c, String p) {
    if (Build.VERSION.SDK_INT < 23) return true;   // Android 5.x: as permissões são dadas ao instalar
    return c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
  }
  /** a bateria não mata a app: antes do Android 6 não existe este limite */
  static boolean battery(Context c) {
    if (Build.VERSION.SDK_INT < 23) return true;
    try { return ((PowerManager) c.getSystemService(Context.POWER_SERVICE)).isIgnoringBatteryOptimizations(c.getPackageName()); } catch (Exception e) { return false; }
  }
}
