package com.vidik.aurummb;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.telecom.PhoneAccountHandle;
import android.telecom.TelecomManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;

/** Envia um código USSD pelo cartão certo (SIM 1 ou SIM 2). Só funciona com códigos de uma resposta; menus com várias respostas não. */
final class UssdRunner implements MbEngine.Ussd {
  final Context c;
  UssdRunner(Context c) { this.c = c; }

  static int subId(Context c, int slot) {
    try {
      if (!Perm.has(c, Manifest.permission.READ_PHONE_STATE)) return -1;
      SubscriptionManager sm = (SubscriptionManager) c.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
      SubscriptionInfo si = sm.getActiveSubscriptionInfoForSimSlotIndex(slot); return si == null ? -1 : si.getSubscriptionId();
    } catch (Exception e) { return -1; }
  }
  /** nome da operadora que o Android vê em cada ranhura, para ajudar a preencher o cartão */
  static String info(Context c) {
    StringBuilder b = new StringBuilder("[");
    try {
      if (Perm.has(c, Manifest.permission.READ_PHONE_STATE)) {
        SubscriptionManager sm = (SubscriptionManager) c.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE); boolean f = true;
        for (SubscriptionInfo si : sm.getActiveSubscriptionInfoList()) { if (!f) b.append(','); f = false; b.append("{\"slot\":").append(si.getSimSlotIndex()).append(",\"name\":").append(Codec.q(String.valueOf(si.getCarrierName()))).append('}'); }
      }
    } catch (Exception e) { }
    return b.append(']').toString();
  }

  public void send(int slot, final String code, final MbEngine.Cb cb) {
    if (!Perm.has(c, Manifest.permission.CALL_PHONE)) { cb.done(1, "sem permissão de chamadas: ative-a nas definições da app"); return; }
    if (Build.VERSION.SDK_INT < 26) { legacy(slot, code, cb); return; }   // Android 5 a 7: marca o código e a Acessibilidade lê a resposta
    if (code.contains("|")) { menu(slot, code.split("\\|"), cb); return; }
    Modern.send(c, slot, code, cb);
  }

  /** Android 5.1 a 7.1: marca o USSD como chamada; a Acessibilidade responde aos passos e lê a resposta final */
  void legacy(int slot, String code, final MbEngine.Cb cb) {
    String[] parts = code.split("\\|");
    String[] steps = java.util.Arrays.copyOfRange(parts, 1, parts.length);
    if (!UssdAccess.begin(steps, cb)) { cb.done(1, "o serviço de Acessibilidade da Aurum MB está desligado: ligue-o nas definições"); return; }
    try {
      Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(parts[0])));
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      // telemóveis com dois cartões: cada fabricante usa um nome para a ranhura; põe os mais comuns
      for (String k : new String[]{"com.android.phone.extra.slot", "slot", "simSlot", "simslot", "sim_slot", "slotId", "slot_id", "simId", "subscription", "Subscription", "phone"}) i.putExtra(k, slot);
      i.putExtra("com.android.phone.force.slot", true);
      c.startActivity(i);
    } catch (Exception e) { UssdAccess.Session s = UssdAccess.cur; if (s != null) UssdAccess.finish(s, 1, "não consegui marcar o USSD: " + e.getMessage(), false); }
  }

  /** USSD com menus: marca o 1.º código e a Acessibilidade responde aos passos seguintes */
  void menu(int slot, final String[] parts, final MbEngine.Cb cb) {
    final String[] steps = java.util.Arrays.copyOfRange(parts, 1, parts.length);
    if (!UssdAccess.begin(steps, cb)) { cb.done(1, "o serviço de Acessibilidade da Aurum MB está desligado: ligue-o nas definições"); return; }
    try { Modern.place(c, slot, parts[0]); }
    catch (Exception e) { UssdAccess.Session s = UssdAccess.cur; if (s != null) UssdAccess.finish(s, 1, "não consegui marcar o USSD: " + e.getMessage(), false); }
  }

  /** só carrega no Android 8 ou mais recente (as classes não existem nos mais antigos) */
  static final class Modern {
    static void send(Context c, int slot, final String code, final MbEngine.Cb cb) {
      try {
        TelephonyManager tm = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE); int sub = subId(c, slot);
        if (sub >= 0) tm = tm.createForSubscriptionId(sub);
        tm.sendUssdRequest(code, new TelephonyManager.UssdResponseCallback() {
          public void onReceiveUssdResponse(TelephonyManager t, String req, CharSequence resp) { cb.done(0, resp == null ? "" : resp.toString()); }
          public void onReceiveUssdResponseFailed(TelephonyManager t, String req, int fc) { cb.done(1, "a operadora não aceitou o código (erro " + fc + ")"); }
        }, new Handler(Looper.getMainLooper()));
      } catch (SecurityException e) { cb.done(1, "sem permissão: " + e.getMessage()); }
      catch (Exception e) { cb.done(1, "erro ao enviar o USSD: " + e.getMessage()); }
    }
    static void place(Context c, int slot, String code) {
      TelecomManager tm = (TelecomManager) c.getSystemService(Context.TELECOM_SERVICE); Bundle ex = new Bundle();
      java.util.List<PhoneAccountHandle> hs = tm.getCallCapablePhoneAccounts();
      if (hs != null && slot < hs.size()) ex.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, hs.get(slot));
      tm.placeCall(Uri.fromParts("tel", code, null), ex);
    }
  }
}
