package com.vidik.aurummb;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;

/** Envia um código USSD pelo cartão certo (SIM 1 ou SIM 2). Só funciona com códigos de uma resposta; menus com várias respostas não. */
final class UssdRunner implements MbEngine.Ussd {
  final Context c;
  UssdRunner(Context c) { this.c = c; }

  static int subId(Context c, int slot) {
    try {
      if (c.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return -1;
      SubscriptionManager sm = (SubscriptionManager) c.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
      SubscriptionInfo si = sm.getActiveSubscriptionInfoForSimSlotIndex(slot); return si == null ? -1 : si.getSubscriptionId();
    } catch (Exception e) { return -1; }
  }
  /** nome da operadora que o Android vê em cada ranhura, para ajudar a preencher o cartão */
  static String info(Context c) {
    StringBuilder b = new StringBuilder("[");
    try {
      if (c.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
        SubscriptionManager sm = (SubscriptionManager) c.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE); boolean f = true;
        for (SubscriptionInfo si : sm.getActiveSubscriptionInfoList()) { if (!f) b.append(','); f = false; b.append("{\"slot\":").append(si.getSimSlotIndex()).append(",\"name\":").append(Codec.q(String.valueOf(si.getCarrierName()))).append('}'); }
      }
    } catch (Exception e) { }
    return b.append(']').toString();
  }

  public void send(int slot, final String code, final MbEngine.Cb cb) {
    if (c.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) { cb.done(1, "sem permissão de chamadas: ative-a nas definições da app"); return; }
    try {
      TelephonyManager tm = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE); int sub = subId(c, slot);
      if (sub >= 0) tm = tm.createForSubscriptionId(sub);
      tm.sendUssdRequest(code, new TelephonyManager.UssdResponseCallback() {
        public void onReceiveUssdResponse(TelephonyManager t, String req, CharSequence resp) { cb.done(0, resp == null ? "" : resp.toString()); }
        public void onReceiveUssdResponseFailed(TelephonyManager t, String req, int fc) { cb.done(1, "a operadora não aceitou o código (erro " + fc + ")"); }
      }, new Handler(Looper.getMainLooper()));
    } catch (SecurityException e) { cb.done(1, "sem permissão: " + e.getMessage()); }
    catch (Exception e) { cb.done(1, "erro ao enviar o USSD: " + e.getMessage()); }
  }
}
