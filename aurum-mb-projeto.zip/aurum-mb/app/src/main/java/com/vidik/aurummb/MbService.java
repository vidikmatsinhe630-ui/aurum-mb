package com.vidik.aurummb;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/** Mantém a Aurum MB viva: a cada segundo vê se há pedido para enviar. */
public class MbService extends Service {
  static final String CH = "mb";
  Handler h; PowerManager.WakeLock wl; boolean run;
  final Runnable loop = new Runnable() { public void run() {
    if (!run) return;
    try { MbEngine e = MbHub.get(MbService.this); boolean started = e.tick(System.currentTimeMillis()); if (started) MbHub.notifyUi(); MbHub.sendStatus(MbService.this, false); } catch (Exception x) { }
    h.postDelayed(this, 1000);
  } };

  public int onStartCommand(Intent i, int f, int id) {
    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    if (android.os.Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CH, "Aurum MB", NotificationManager.IMPORTANCE_LOW));
    PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
    Notification n = new Notification.Builder(this, CH).setContentTitle("Aurum MB ativa").setContentText("À espera de pedidos da Aurum").setSmallIcon(android.R.drawable.stat_notify_sync).setContentIntent(pi).setOngoing(true).build();
    try { startForeground(7, n); } catch (Exception e) { stopSelf(); return START_NOT_STICKY; }
    if (h == null) h = new Handler(Looper.getMainLooper());
    if (wl == null) { wl = ((PowerManager) getSystemService(Context.POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aurummb:svc"); wl.setReferenceCounted(false); }
    if (!wl.isHeld()) wl.acquire(12 * 3600 * 1000L);
    if (!run) { run = true; h.post(loop); }
    return START_STICKY;
  }
  public void onDestroy() { run = false; if (wl != null && wl.isHeld()) wl.release(); super.onDestroy(); }
  public IBinder onBind(Intent i) { return null; }

  static void start(Context c) { try { c.startForegroundService(new Intent(c, MbService.class)); } catch (Exception e) { } }
}
