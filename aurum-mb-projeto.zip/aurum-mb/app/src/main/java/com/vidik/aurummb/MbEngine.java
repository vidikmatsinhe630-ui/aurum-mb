package com.vidik.aurummb;

import java.util.*;

/** Núcleo da Aurum MB: 2 cartões SIM com rotação, fila de pedidos com repetição, pacote por tempo, lugares da tabela,
 *  números bloqueados, painel de erros e avisos à Aurum. Java puro: o Android só empresta o USSD, o relógio e o armazenamento. */
final class MbEngine {
  interface KV { String get(String k, String d); void set(String k, String v); }
  interface Cb { void done(int status, String text); }          // status 0 = a operadora respondeu; 1 = falha técnica do USSD
  interface Ussd { void send(int slot, String code, Cb cb); }    // assíncrono
  interface Out { boolean aurum(String type, String json); void changed(); }  // devolve true se o aviso saiu

  static final long DAY = 86400000L;
  static final int MAXTRY = 10, SLOTS_BASE = 10;
  static final String OKW = "sucesso,success,enviado,transferid,efectuad,efetuad,concluid";
  static final String[] FAILW = {"erro", "falh", "invalid", "inválid", "recus", "indispon", "tente", "nao foi possivel", "não foi possível", "timeout"};
  static final String[] NOBAL = {"insuficiente", "sem saldo", "saldo insuf"};

  static final class Sim { int n; String op = "Vodacom", st = "lib", ussd = "", ok = OKW; long mb; int tries; }
  static final class Order { String id = "", phone = "", state = "fila", note = ""; long mb, mt, at, done, next; int sim, att; boolean confirm; }
  static final class Err { long t; String src = "", code = "", opt = "", msg = "", hint = ""; }
  static final class Msg { long t; String type = "", text = ""; boolean sent; }
  static final class Tel { String n = ""; boolean b; long last; }

  static final Map<String, String> OPT = new HashMap<>(), ECODE = new HashMap<>();
  static {
    OPT.put("Aurum", "Receber pedido da Aurum"); OPT.put("SIM", "Escolher o cartão SIM"); OPT.put("USSD", "Enviar megas por USSD");
    OPT.put("Rede", "Avisar a Aurum"); OPT.put("Pacote", "Pacote de tempo"); OPT.put("Tabela", "Tabela de preços");
    ECODE.put("Aurum", "E1"); ECODE.put("SIM", "E2"); ECODE.put("USSD", "E3"); ECODE.put("Rede", "E4"); ECODE.put("Pacote", "E5"); ECODE.put("Tabela", "E6");
  }

  final KV kv; final Ussd ussd; final Out out; java.util.function.LongSupplier time = System::currentTimeMillis;
  final Sim[] sims = {new Sim(), new Sim()};
  final String[][] prices = new String[MbCode.MAX_SLOTS][];
  final List<Tel> tels = new ArrayList<>(); final List<Order> orders = new ArrayList<>();
  final List<Err> errs = new ArrayList<>(); final List<Msg> msgs = new ArrayList<>(); final Set<String> used = new HashSet<>();
  boolean on = true, cf = true, sc = true, alerted, expNoted;
  int slots = SLOTS_BASE, cur; long end, seen; String linkCode = "", device = ""; long linkedAt; long profit;

  MbEngine(KV kv, Ussd ussd, Out out) {
    this.kv = kv; this.ussd = ussd; this.out = out;
    sims[0].n = 1; sims[1].n = 2; for (int i = 0; i < prices.length; i++) prices[i] = new String[]{"", "", ""};
    load();
  }

  // ---------- tempo ----------
  /** o relógio nunca anda para trás: recuar a data do telemóvel não devolve dias */
  synchronized long clock(long now) { if (now > seen) seen = now; return seen; }
  synchronized boolean blocked(long now) { return end <= clock(now); }

  // ---------- erros e avisos ----------
  synchronized void err(long now, String src, String msg, String hint, String opt) {
    Err e = new Err(); e.t = now; e.src = src; e.msg = msg; e.hint = hint == null ? "" : hint; e.opt = opt == null || opt.isEmpty() ? OPT.getOrDefault(src, src) : opt; e.code = ECODE.getOrDefault(src, "E0");
    errs.add(0, e); while (errs.size() > 200) errs.remove(errs.size() - 1);
  }
  synchronized void tell(long now, String type, String text, String json) {
    Msg m = new Msg(); m.t = now; m.type = type; m.text = text; m.sent = out != null && out.aurum(type, json);
    msgs.add(0, m); while (msgs.size() > 30) msgs.remove(msgs.size() - 1);
    if (!m.sent) err(now, "Rede", "Não consegui avisar a Aurum: " + text, "Confirme que a Aurum está instalada e ligada.", "Avisar a Aurum");
  }
  synchronized void clearErrs() { errs.clear(); save(); }

  // ---------- ligação à Aurum ----------
  synchronized String link(String code, String dev, long now) {
    if (!MbCode.linkFormat(code)) return "ERR:Código incompleto. O formato é MB-XXXX-XXXX.";
    linkCode = MbCode.clean(code); device = dev == null ? "" : dev; linkedAt = clock(now); save(); return "";
  }
  synchronized void unlink(long now) {
    if (linkedAt > 0) tell(now, "UNLINK", "Aurum MB desligada pelo utilizador.", "{\"type\":\"UNLINK\"}");
    linkCode = ""; device = ""; linkedAt = 0; save();
  }
  synchronized boolean linked() { return linkedAt > 0; }
  /** a Aurum só fala com a MB se mandar o código desta ligação */
  synchronized boolean codeOk(String c) { return linkedAt > 0 && MbCode.clean(c).equals(linkCode); }

  // ---------- pacote e lugares ----------
  synchronized String redeem(String code, long now) {
    long n = clock(now); String c = MbCode.clean(code); String[] p = MbCode.parse(c);
    if (p == null) { err(n, "Pacote", "Código de ativação inválido.", "Confira o código e escreva outra vez.", "Ativar código"); save(); return "ERR:Código inválido. Confira e escreva outra vez."; }
    if (used.contains(c)) { err(n, "Pacote", "Este código já foi usado.", "Cada código só vale uma vez.", "Ativar código"); save(); return "ERR:Este código já foi usado."; }
    if (p[0].equals("LUG")) {
      if (slots >= MbCode.MAX_SLOTS) return "ERR:Já tem " + MbCode.MAX_SLOTS + " lugares.";
      slots = Math.min(MbCode.MAX_SLOTS, slots + 10); used.add(c); save(); return "";
    }
    int d = Codec.i(p[1], 0); boolean was = end <= n; end = (was ? n : end) + d * DAY; used.add(c); expNoted = false;
    if (was) { alerted = false; tell(n, "RESUME", "Pacote pago. A Aurum MB voltou a transferir.", "{\"type\":\"RESUME\"}"); wake(n); }
    save(); return "";
  }
  synchronized long left(long now) { return Math.max(0, end - clock(now)); }

  // ---------- painel ----------
  synchronized void setOn(boolean v) { on = v; save(); }
  synchronized void setCf(boolean v) { cf = v; save(); }
  synchronized void setSc(boolean v) { sc = v; save(); }

  synchronized void saveSim(int n, String op, long mb, String st, String ussdTpl, String okw, long now) {
    Sim s = sims[n - 1]; if (op != null && !op.isEmpty()) s.op = op; s.mb = Math.max(0, mb); s.ussd = ussdTpl == null ? "" : ussdTpl.trim();
    s.ok = okw == null || okw.trim().isEmpty() ? OKW : okw.trim();
    boolean cfg = !s.ussd.isEmpty();
    if (st != null && !st.equals(s.st)) setSimState(n, st, now); else { save(); if (cfg) wake(clock(now)); }
  }
  /** o ADM liberta ou esgota um cartão; ao liberar, zera as transferências e retoma os pedidos em espera */
  synchronized void setSimState(int n, String st, long now) {
    Sim s = sims[n - 1]; long t = clock(now); if (s.st.equals(st)) return; s.st = st;
    if (st.equals("lib")) { s.tries = 0; cur = n - 1; if (alerted) { alerted = false; tell(t, "RESUME", "Cartão " + n + " liberado. A Aurum MB voltou a transferir.", "{\"type\":\"RESUME\"}"); } wake(t); }
    save();
  }
  /** pedidos em espera voltam à fila */
  synchronized void wake(long now) { for (Order o : orders) if (o.state.equals("esp")) { o.state = "fila"; o.next = now; } }

  // ---------- tabela ----------
  /** guarda as linhas visíveis (as bloqueadas são ignoradas). Devolve os erros de preenchimento, uma linha cada. */
  synchronized List<String> savePrices(String[][] rows, long now) {
    List<String> bad = new ArrayList<>(); long t = clock(now);
    for (int i = 0; i < slots && i < rows.length; i++) {
      String[] r = rows[i]; String a = digits(r[0]), b = digits(r[1]), c = digits(r.length > 2 ? r[2] : "");
      boolean has = !a.isEmpty() || !b.isEmpty();
      if (has && (a.isEmpty() || b.isEmpty())) { String m = "Linha " + (i + 1) + " incompleta: falta " + (a.isEmpty() ? "o preço em MT" : "o valor de MB") + "."; bad.add(m); err(t, "Tabela", m, "Preencha os dois campos ou apague a linha.", "Tabela de preços, linha " + (i + 1)); continue; }
      prices[i] = new String[]{a, b, c};
    }
    for (int i = slots; i < prices.length; i++) prices[i] = new String[]{"", "", ""};
    save(); return bad;
  }
  static String digits(String s) { return s == null ? "" : s.replaceAll("\\D", ""); }
  synchronized String[] priceFor(long mt, long mb) { for (int i = 0; i < slots; i++) { String[] r = prices[i]; if (!r[0].isEmpty() && !r[1].isEmpty() && Codec.l(r[0], -1) == mt && Codec.l(r[1], -1) == mb) return r; } return null; }

  // ---------- números ----------
  synchronized String addTel(String n, long now) {
    String p = phone(n); if (p == null) return "ERR:Escreva um número com 9 dígitos.";
    for (Tel t : tels) if (t.n.equals(p)) return "ERR:Este número já está na lista.";
    Tel t = new Tel(); t.n = p; t.last = 0; tels.add(0, t); save(); return "";
  }
  synchronized void toggleTel(String n) { for (Tel t : tels) if (t.n.equals(n)) t.b = !t.b; save(); }
  /** 9 dígitos a começar por 8; aceita 258 à frente */
  static String phone(String s) { String d = digits(s); if (d.length() == 12 && d.startsWith("258")) d = d.substring(3); return d.length() == 9 && d.charAt(0) == '8' ? d : null; }

  // ---------- pedidos ----------
  /** a Aurum (ou o teste manual) manda um pedido. "" = aceite (ou repetido); "ERR:…" = recusado, com o motivo gravado nos erros. */
  synchronized String submit(String id, String phoneRaw, long mb, long mt, boolean confirm, long now) {
    long t = clock(now);
    for (Order o : orders) if (o.id.equals(id)) return "";   // o mesmo pedido não paga duas vezes
    if (end <= t) { String m = "Pedido recusado: o pacote da Aurum MB acabou."; err(t, "Pacote", m, "Pague um pacote para voltar a trabalhar.", ""); reject(id, phoneRaw, mb, mt, "Pacote terminado", t); return "ERR:" + m; }
    if (!on) { String m = "Pedido recusado porque a app está parada."; err(t, "Aurum", m, "Ligue o Estado no Painel.", ""); reject(id, phoneRaw, mb, mt, "App parada", t); return "ERR:" + m; }
    String p = phone(phoneRaw);
    if (p == null) { String m = "Número inválido: " + phoneRaw + "."; err(t, "Aurum", m, "Peça ao cliente o número certo (9 dígitos).", ""); reject(id, phoneRaw, mb, mt, "Número inválido", t); return "ERR:" + m; }
    for (Tel x : tels) if (x.n.equals(p) && x.b) { String m = "Número bloqueado: " + p + "."; err(t, "Aurum", m, "Libere o número em Banco de dados, Telemóveis.", ""); reject(id, p, mb, mt, "Número bloqueado", t); return "ERR:" + m; }
    if (priceFor(mt, mb) == null) { String m = "Pedido fora da tabela: " + mb + " MB por " + mt + " MT."; err(t, "Tabela", m, "Acrescente esta linha em Banco de dados, Preço.", ""); reject(id, p, mb, mt, "Fora da tabela", t); return "ERR:" + m; }
    Order o = new Order(); o.id = id; o.phone = p; o.mb = mb; o.mt = mt; o.confirm = confirm && cf; o.at = t; o.next = t; orders.add(0, o);
    while (orders.size() > 300) orders.remove(orders.size() - 1);
    save(); return "";
  }
  private void reject(String id, String p, long mb, long mt, String why, long t) {
    Order o = new Order(); o.id = id; o.phone = p == null ? "" : p; o.mb = mb; o.mt = mt; o.state = "rec"; o.note = why; o.at = t; o.done = t; orders.add(0, o);
    tell(t, "REFUSED", "Pedido " + id + " recusado: " + why + ".", "{\"type\":\"REFUSED\",\"id\":" + Codec.q(id) + ",\"why\":" + Codec.q(why) + "}");
    save();
  }
  /** escolhe o cartão: o atual primeiro; esgotado, sem megas ou com 10 feitas passa para o outro */
  private Sim pick(long need, long t) {
    int[] ord = {cur, 1 - cur};
    for (int k : ord) {
      Sim s = sims[k]; if (!s.st.equals("lib")) continue;
      if (s.tries >= MAXTRY) { s.st = "esg"; err(t, "SIM", "Cartão " + s.n + " chegou a " + MAXTRY + " transferências. Passa para o outro cartão.", "", ""); continue; }
      if (s.mb < need) { s.st = "esg"; err(t, "SIM", "Cartão " + s.n + " ficou sem megas antes do tempo. Troquei para o outro cartão.", "Carregue o cartão " + s.n + " e libere-o em Editar.", ""); continue; }
      if (k != cur) { cur = k; err(t, "SIM", "Troquei para o cartão " + s.n + ".", "", ""); }
      return s;
    }
    return null;
  }
  static String build(String tpl, String phone, long mb, long mt) { return tpl.replace("{NUM}", phone).replace("{MB}", String.valueOf(mb)).replace("{MT}", String.valueOf(mt)); }

  /** chamado a cada segundo pelo serviço (e depois de cada pedido): arranca o próximo pedido se nada estiver a correr */
  synchronized boolean tick(long now) {
    long t = clock(now);
    for (Order o : orders) if (o.state.equals("env") && t - o.at > 0 && t - o.done > 90000 && o.done > 0) { onResult(o.id, 1, "sem resposta da operadora em 90 s", t); }
    for (Order o : orders) if (o.state.equals("env")) return false;
    if (end <= t) {
      if (end > 0 && !expNoted) { expNoted = true; err(t, "Pacote", "O pacote acabou. A app foi bloqueada.", "Pague um pacote para voltar a receber pedidos da Aurum.", ""); tell(t, "BLOCKED", "Pacote terminado. Transferências paradas.", "{\"type\":\"BLOCKED\"}"); save(); }
      for (Order o : orders) if (o.state.equals("fila")) { o.state = "esp"; o.note = "Pacote terminado"; }
      return false;
    }
    Order n = null; for (int i = orders.size() - 1; i >= 0; i--) { Order o = orders.get(i); if ((o.state.equals("fila")) && o.next <= t) { n = o; break; } }
    if (n == null) return false;
    Sim s = pick(n.mb, t);
    if (s == null) { n.state = "esp"; n.note = "Sem cartão liberado"; if (!alerted) { alerted = true; err(t, "SIM", "Os 2 cartões estão esgotados. Os pedidos ficam em espera.", "O ADM deve liberar um cartão em Editar.", ""); tell(t, "WAIT", "Os 2 cartões esgotaram. Pedidos em espera.", "{\"type\":\"WAIT\"}"); } save(); return false; }
    if (s.ussd.isEmpty()) { n.state = "esp"; n.note = "Sem código USSD"; err(t, "USSD", "O cartão " + s.n + " não tem código USSD definido.", "Em Editar, escreva o código da operadora. Exemplo: *123*{NUM}*{MB}#", "Enviar megas por USSD (cartão " + s.n + ")"); save(); return false; }
    String code = build(s.ussd, n.phone, n.mb, n.mt);
    n.state = "env"; n.sim = s.n; n.att++; n.done = t; save();
    final String id = n.id; final int slot = s.n - 1;
    try { ussd.send(slot, code, (st, tx) -> onResult(id, st, tx, time.getAsLong())); }
    catch (Exception e) { onResult(id, 1, "erro ao abrir o USSD: " + e.getMessage(), t); }
    return true;
  }

  static boolean has(String text, String csv) { String x = text.toLowerCase(Locale.ROOT); for (String w : csv.split(",")) if (!w.trim().isEmpty() && x.contains(w.trim().toLowerCase(Locale.ROOT))) return true; return false; }
  static boolean hasAny(String text, String[] ws) { String x = text.toLowerCase(Locale.ROOT); for (String w : ws) if (x.contains(w)) return true; return false; }

  synchronized void onResult(String id, int status, String text, long now) {
    long t = clock(now); Order o = find(id); if (o == null || !o.state.equals("env")) return;
    Sim s = sims[o.sim - 1]; String tx = text == null ? "" : text.trim();
    if (status == 0 && has(tx, s.ok)) { success(o, s, t); return; }
    String opt = "Enviar megas por USSD (cartão " + s.n + ")";
    if (status == 0 && hasAny(tx, NOBAL)) { s.st = "esg"; o.state = "fila"; o.next = t; err(t, "SIM", "Cartão " + s.n + " sem saldo de megas: " + cut(tx) + ". Passo para o outro cartão.", "Carregue o cartão " + s.n + " e libere-o em Editar.", opt); save(); return; }
    if (status == 1 || hasAny(tx, FAILW)) {
      long wait = Math.min(60000, 5000L * o.att); o.state = "fila"; o.next = t + wait; o.note = "A insistir (tentativa " + o.att + ")";
      err(t, "USSD", (status == 1 ? "O pedido USSD falhou: " : "A operadora recusou: ") + cut(tx) + " Insisto até enviar (tentativa " + o.att + ").", "Verifique o sinal do cartão " + s.n + ".", opt); save(); return;
    }
    o.state = "chk"; o.note = "Confirmar";
    err(t, "USSD", "Resposta que não reconheço: " + cut(tx), "Veja se o cliente recebeu os megas e toque em Entregue ou Tentar de novo.", opt); save();
  }
  static String cut(String s) { return s.length() > 140 ? s.substring(0, 140) + "…" : s; }

  private void success(Order o, Sim s, long t) {
    s.mb = Math.max(0, s.mb - o.mb); s.tries++;
    if (s.tries >= MAXTRY) { s.st = "esg"; err(t, "SIM", "Cartão " + s.n + " chegou a " + MAXTRY + " transferências. Passa para o outro cartão.", "", ""); }
    o.state = "ok"; o.note = ""; o.done = t;
    String[] pr = priceFor(o.mt, o.mb); if (pr != null) profit += Codec.l(pr[2], 0);
    Tel f = null; for (Tel x : tels) if (x.n.equals(o.phone)) f = x; if (f == null) { f = new Tel(); f.n = o.phone; tels.add(0, f); } f.last = t;
    tell(t, "RESULT", "Entregue " + o.mb + " MB a " + o.phone + ".", "{\"type\":\"RESULT\",\"id\":" + Codec.q(o.id) + ",\"ok\":true,\"phone\":" + Codec.q(o.phone) + ",\"mb\":" + o.mb + ",\"confirm\":" + o.confirm + "}");
    save();
  }
  /** pedido com resposta duvidosa: o ADM decide */
  synchronized void confirmOrder(String id, boolean delivered, long now) {
    long t = clock(now); Order o = find(id); if (o == null || !o.state.equals("chk")) return;
    if (delivered) success(o, sims[Math.max(0, o.sim - 1)], t); else { o.state = "fila"; o.next = t; o.note = "Tentar de novo"; save(); }
  }
  Order find(String id) { for (Order o : orders) if (o.id.equals(id)) return o; return null; }
  synchronized int count(String st) { int n = 0; for (Order o : orders) if (o.state.equals(st)) n++; return n; }

  // ---------- estado para a interface ----------
  synchronized String state(long now) {
    long t = clock(now); StringBuilder b = new StringBuilder("{");
    b.append("\"linked\":").append(linkedAt > 0).append(",\"code\":").append(Codec.q(linkCode)).append(",\"device\":").append(Codec.q(device));
    b.append(",\"on\":").append(on).append(",\"cf\":").append(cf).append(",\"sc\":").append(sc).append(",\"slots\":").append(slots);
    b.append(",\"end\":").append(end).append(",\"left\":").append(Math.max(0, end - t)).append(",\"blocked\":").append(end <= t).append(",\"cur\":").append(cur).append(",\"max\":").append(MAXTRY);
    b.append(",\"waiting\":").append(count("esp") + count("fila")).append(",\"profit\":").append(profit).append(",\"now\":").append(t);
    b.append(",\"sims\":["); for (int i = 0; i < 2; i++) { Sim s = sims[i]; if (i > 0) b.append(','); b.append("{\"n\":").append(s.n).append(",\"op\":").append(Codec.q(s.op)).append(",\"mb\":").append(s.mb).append(",\"st\":").append(Codec.q(s.st)).append(",\"tries\":").append(s.tries).append(",\"ussd\":").append(Codec.q(s.ussd)).append(",\"ok\":").append(Codec.q(s.ok)).append('}'); }
    b.append("],\"preco\":["); for (int i = 0; i < prices.length; i++) { if (i > 0) b.append(','); b.append('[').append(Codec.q(prices[i][0])).append(',').append(Codec.q(prices[i][1])).append(',').append(Codec.q(prices[i][2])).append(']'); }
    b.append("],\"tels\":["); for (int i = 0; i < tels.size(); i++) { Tel x = tels.get(i); if (i > 0) b.append(','); b.append("{\"n\":").append(Codec.q(x.n)).append(",\"b\":").append(x.b).append(",\"last\":").append(x.last).append('}'); }
    b.append("],\"tx\":["); int k = 0; for (Order o : orders) { if (k++ >= 40) break; if (k > 1) b.append(','); b.append("{\"id\":").append(Codec.q(o.id)).append(",\"phone\":").append(Codec.q(o.phone)).append(",\"mb\":").append(o.mb).append(",\"mt\":").append(o.mt).append(",\"s\":").append(Codec.q(o.state)).append(",\"sim\":").append(o.sim).append(",\"att\":").append(o.att).append(",\"note\":").append(Codec.q(o.note)).append(",\"at\":").append(o.at).append(",\"done\":").append(o.done).append('}'); }
    b.append("],\"errs\":["); for (int i = 0; i < errs.size(); i++) { Err e = errs.get(i); if (i > 0) b.append(','); b.append("{\"t\":").append(e.t).append(",\"src\":").append(Codec.q(e.src)).append(",\"c\":").append(Codec.q(e.code)).append(",\"o\":").append(Codec.q(e.opt)).append(",\"m\":").append(Codec.q(e.msg)).append(",\"h\":").append(Codec.q(e.hint)).append('}'); }
    b.append("],\"msgs\":["); for (int i = 0; i < msgs.size(); i++) { Msg m = msgs.get(i); if (i > 0) b.append(','); b.append("{\"t\":").append(m.t).append(",\"type\":").append(Codec.q(m.type)).append(",\"m\":").append(Codec.q(m.text)).append(",\"sent\":").append(m.sent).append('}'); }
    return b.append("]}").toString();
  }

  // ---------- armazenamento ----------
  synchronized void save() {
    StringBuilder s = new StringBuilder();
    for (Sim x : sims) s.append(Codec.join(x.n, x.op, x.mb, x.st, x.tries, x.ussd, x.ok)).append('\n'); kv.set("mb_sims", s.toString());
    s.setLength(0); for (int i = 0; i < prices.length; i++) s.append(Codec.join((Object[]) prices[i])).append('\n'); kv.set("mb_prices", s.toString());
    s.setLength(0); for (Tel x : tels) s.append(Codec.join(x.n, x.b, x.last)).append('\n'); kv.set("mb_tels", s.toString());
    s.setLength(0); for (Order o : orders) s.append(Codec.join(o.id, o.phone, o.mb, o.mt, o.state, o.sim, o.att, o.at, o.done, o.next, o.note, o.confirm)).append('\n'); kv.set("mb_orders", s.toString());
    s.setLength(0); for (Err e : errs) s.append(Codec.join(e.t, e.src, e.code, e.opt, e.msg, e.hint)).append('\n'); kv.set("mb_errs", s.toString());
    s.setLength(0); for (Msg m : msgs) s.append(Codec.join(m.t, m.type, m.text, m.sent)).append('\n'); kv.set("mb_msgs", s.toString());
    kv.set("mb_main", Codec.join(on, cf, sc, slots, cur, end, seen, linkCode, device, linkedAt, profit, alerted, String.join(",", used)));
    if (out != null) out.changed();
  }
  private static String[] lines(String v) { List<String> l = new ArrayList<>(); for (String x : v.split("\n")) if (!x.isEmpty()) l.add(x); return l.toArray(new String[0]); }
  private void load() {
    try {
      String[] m = Codec.split(kv.get("mb_main", ""));
      if (m.length >= 13) { on = m[0].equals("true"); cf = m[1].equals("true"); sc = m[2].equals("true"); slots = Math.max(SLOTS_BASE, Math.min(MbCode.MAX_SLOTS, Codec.i(m[3], 10))); cur = Codec.i(m[4], 0) == 1 ? 1 : 0; end = Codec.l(m[5], 0); seen = Codec.l(m[6], 0); linkCode = m[7]; device = m[8]; linkedAt = Codec.l(m[9], 0); profit = Codec.l(m[10], 0); alerted = m[11].equals("true"); for (String u : m[12].split(",")) if (!u.isEmpty()) used.add(u); }
      for (String ln : lines(kv.get("mb_sims", ""))) { String[] f = Codec.split(ln); if (f.length < 7) continue; int n = Codec.i(f[0], 0); if (n < 1 || n > 2) continue; Sim s = sims[n - 1]; s.op = f[1]; s.mb = Codec.l(f[2], 0); s.st = f[3].equals("esg") ? "esg" : "lib"; s.tries = Codec.i(f[4], 0); s.ussd = f[5]; s.ok = f[6].isEmpty() ? OKW : f[6]; }
      int i = 0; for (String ln : kv.get("mb_prices", "").split("\n")) { if (i >= prices.length) break; String[] f = Codec.split(ln); if (f.length >= 3) prices[i] = new String[]{f[0], f[1], f[2]}; i++; }
      for (String ln : lines(kv.get("mb_tels", ""))) { String[] f = Codec.split(ln); if (f.length < 3) continue; Tel t = new Tel(); t.n = f[0]; t.b = f[1].equals("true"); t.last = Codec.l(f[2], 0); tels.add(t); }
      for (String ln : lines(kv.get("mb_orders", ""))) {
        String[] f = Codec.split(ln); if (f.length < 12) continue; Order o = new Order(); o.id = f[0]; o.phone = f[1]; o.mb = Codec.l(f[2], 0); o.mt = Codec.l(f[3], 0); o.state = f[4]; o.sim = Codec.i(f[5], 0); o.att = Codec.i(f[6], 0); o.at = Codec.l(f[7], 0); o.done = Codec.l(f[8], 0); o.next = Codec.l(f[9], 0); o.note = f[10]; o.confirm = f[11].equals("true");
        if (o.state.equals("env")) { o.state = "chk"; o.note = "A app fechou durante o envio. Confirme"; }   // não repete sozinha: podia entregar duas vezes
        orders.add(o);
      }
      for (String ln : lines(kv.get("mb_errs", ""))) { String[] f = Codec.split(ln); if (f.length < 6) continue; Err e = new Err(); e.t = Codec.l(f[0], 0); e.src = f[1]; e.code = f[2]; e.opt = f[3]; e.msg = f[4]; e.hint = f[5]; errs.add(e); }
      for (String ln : lines(kv.get("mb_msgs", ""))) { String[] f = Codec.split(ln); if (f.length < 4) continue; Msg g = new Msg(); g.t = Codec.l(f[0], 0); g.type = f[1]; g.text = f[2]; g.sent = f[3].equals("true"); msgs.add(g); }
    } catch (Exception e) { /* estado danificado: recomeça vazio em vez de falhar */ }
  }
}
