package com.vidik.aurummb;

import java.util.*;

/** Códigos de ativação da Aurum MB (vêm depois do pagamento). Assinados, de uso único.
 *  PCT-<dias>-<6 letras>-<4 de assinatura>: pacote de tempo (7, 15, 25, 32 ou 62 dias)
 *  LUG-10-<6 letras>-<4 de assinatura>: mais 10 lugares na tabela (permanente)
 *  Provisório: o segredo vai na app. O SEGREDO tem de ser igual ao de tools/mb_codigo.py e deve ser trocado. Puro. */
final class MbCode {
  static final String SECRET = "aurum-mb-troque-este-segredo";
  static final String A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  static final int[][] PKG = {{7, 69}, {15, 99}, {25, 149}, {32, 199}, {62, 289}};
  static final int LUG_PRICE = 75, MAX_SLOTS = 20;

  static boolean validDays(int d) { for (int[] p : PKG) if (p[0] == d) return true; return false; }
  static String sign(String kind, int n, String rnd) {
    try { javax.crypto.Mac m = javax.crypto.Mac.getInstance("HmacSHA256"); m.init(new javax.crypto.spec.SecretKeySpec(SECRET.getBytes("UTF-8"), "HmacSHA256"));
      byte[] h = m.doFinal((kind + "-" + n + "-" + rnd).getBytes("UTF-8")); StringBuilder s = new StringBuilder(); for (int i = 0; i < 4; i++) s.append(A.charAt((h[i] & 0xff) % A.length())); return s.toString();
    } catch (Exception e) { return "????"; }
  }
  static String make(String kind, int n, Random r) { StringBuilder s = new StringBuilder(); for (int i = 0; i < 6; i++) s.append(A.charAt(r.nextInt(A.length()))); String rn = s.toString(); return kind + "-" + n + "-" + rn + "-" + sign(kind, n, rn); }
  static String clean(String c) { return c == null ? "" : c.trim().toUpperCase(Locale.ROOT).replace(" ", ""); }
  /** {tipo, n} se o código é válido; senão null */
  static String[] parse(String code) {
    String[] p = clean(code).split("-");
    if (p.length != 4) return null;
    if (!p[0].equals("PCT") && !p[0].equals("LUG")) return null;
    int n = Codec.i(p[1], 0);
    if (p[0].equals("PCT") ? !validDays(n) : n != 10) return null;
    if (!sign(p[0], n, p[2]).equals(p[3])) return null;
    return new String[]{p[0], String.valueOf(n)};
  }
  /** formato do código que liga a Aurum MB à Aurum: MB-XXXX-XXXX */
  static boolean linkFormat(String c) { return clean(c).matches("MB-[" + A + "]{4}-[" + A + "]{4}"); }
}
