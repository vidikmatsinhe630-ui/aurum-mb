package com.vidik.aurummb;

import java.util.*;

/** Códigos de ativação da Aurum MB (vêm depois do pagamento). Assinados, de uso único.
 *  PCT-<dias>-<6 letras>-<4 de assinatura>: pacote de tempo (7, 15, 25, 32 ou 62 dias; 3 dias = teste grátis)
 *  LUG-10-<6 letras>-<4 de assinatura>: mais 10 lugares na tabela (permanente)
 *  Provisório: o segredo vai na app. O SEGREDO tem de ser igual ao de tools/mb_codigo.py e deve ser trocado. Puro. */
final class MbCode {
  static final String SECRET = "aurum-mb-troque-este-segredo";
  static final String A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  static final int[][] PKG = {{5, 49}, {13, 99}, {22, 139}, {32, 179}, {64, 299}};   // pacotes à venda
  static final int[] OLD = {7, 15, 25, 62};   // códigos antigos que já foram dados a clientes continuam a valer
  static final int LUG_PRICE = 75, MAX_SLOTS = 20;

  static final int TRIAL = 3;   // teste grátis: não está na lista de preços, só o dono gera estes códigos
  static boolean validDays(int d) { if (d == TRIAL) return true; for (int[] p : PKG) if (p[0] == d) return true; for (int o : OLD) if (o == d) return true; return false; }
  /** preço do pacote à venda, ou -1 */
  static int price(int days) { for (int[] p : PKG) if (p[0] == days) return p[1]; return -1; }

  // ---- pagamento por e-Mola: o cliente cola o ID da transação; a Aurum do dono acha-o nas SMS e devolve o código ----
  /** só letras e números, maiúsculas (os pontos do ID não contam) */
  static String norm(String id) { StringBuilder b = new StringBuilder(); String u = id == null ? "" : id.toUpperCase(Locale.ROOT); for (int i = 0; i < u.length(); i++) { char ch = u.charAt(i); if ((ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9')) b.append(ch); } return b.toString(); }
  static boolean idOk(String n) { return n.length() >= 10 && n.length() <= 24 && n.matches(".*[A-Z].*") && n.matches(".*[0-9].*"); }
  private static byte[] mac(String s) { try { javax.crypto.Mac m = javax.crypto.Mac.getInstance("HmacSHA256"); m.init(new javax.crypto.spec.SecretKeySpec(SECRET.getBytes("UTF-8"), "HmacSHA256")); return m.doFinal(s.getBytes("UTF-8")); } catch (Exception e) { return new byte[32]; } }
  /** o que a MB mostra na caixa pública: não revela o ID (ninguém consegue copiá-lo para roubar o pagamento) */
  static String payHash(String id) { byte[] h = mac("id|" + norm(id)); StringBuilder s = new StringBuilder(); for (int i = 0; i < 10; i++) s.append(String.format("%02x", h[i] & 0xff)); return s.toString(); }
  /** caixa onde só quem sabe o ID lê a resposta: MB-XXXX-XXXX */
  static String payReply(String id) { byte[] h = mac("reply|" + norm(id)); StringBuilder s = new StringBuilder("MB-"); for (int i = 0; i < 8; i++) { if (i == 4) s.append('-'); s.append(A.charAt((h[i] & 0xff) % A.length())); } return s.toString(); }
  static String sign(String kind, int n, String rnd) {
    try { javax.crypto.Mac m = javax.crypto.Mac.getInstance("HmacSHA256"); m.init(new javax.crypto.spec.SecretKeySpec(SECRET.getBytes("UTF-8"), "HmacSHA256"));
      byte[] h = m.doFinal((kind + "-" + n + "-" + rnd).getBytes("UTF-8")); StringBuilder s = new StringBuilder(); for (int i = 0; i < 4; i++) s.append(A.charAt((h[i] & 0xff) % A.length())); return s.toString();
    } catch (Exception e) { return "????"; }
  }
  static String make(String kind, int n, Random r) { StringBuilder s = new StringBuilder(); for (int i = 0; i < 6; i++) s.append(A.charAt(r.nextInt(A.length()))); String rn = s.toString(); return kind + "-" + n + "-" + rn + "-" + sign(kind, n, rn); }
  static String clean(String c) { return c == null ? "" : c.trim().toUpperCase(Locale.ROOT).replace(" ", ""); }
  /** {tipo, n} se o código é válido; senão null */
  static String[] parse(String code) {
    String[] p = clean(code).split("-");
    if (p.length != 4) return null;
    if (!p[0].equals("PCT") && !p[0].equals("LUG")) return null;
    int n = Codec.i(p[1], 0);
    if (p[0].equals("PCT") ? !validDays(n) : n != 10) return null;
    if (!sign(p[0], n, p[2]).equals(p[3])) return null;
    return new String[]{p[0], String.valueOf(n)};
  }
  /** formato do código que liga a Aurum MB à Aurum: MB-XXXX-XXXX */
  static boolean linkFormat(String c) { return clean(c).matches("MB-[" + A + "]{4}-[" + A + "]{4}"); }
}
