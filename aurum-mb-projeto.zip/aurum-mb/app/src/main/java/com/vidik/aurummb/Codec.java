package com.vidik.aurummb;

/** Linhas com campos separados por tabulação, e texto JSON simples. Puro. */
final class Codec {
  /** junta com vírgulas (String.join só existe a partir do Android 8) */
  static String csv(java.util.Collection<String> c) { StringBuilder b = new StringBuilder(); for (String x : c) { if (b.length() > 0) b.append(','); b.append(x); } return b.toString(); }
  static String esc(String s) { return (s == null ? "" : s).replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", ""); }
  static String unesc(String s) {
    StringBuilder b = new StringBuilder();
    for (int i = 0; i < s.length(); i++) { char c = s.charAt(i); if (c == '\\' && i + 1 < s.length()) { char n = s.charAt(++i); b.append(n == 'n' ? '\n' : n == 't' ? '\t' : n); } else b.append(c); }
    return b.toString();
  }
  static String join(Object... f) { StringBuilder b = new StringBuilder(); for (int i = 0; i < f.length; i++) { if (i > 0) b.append('\t'); b.append(esc(String.valueOf(f[i]))); } return b.toString(); }
  static String[] split(String line) { String[] p = line.split("\t", -1); for (int i = 0; i < p.length; i++) p[i] = unesc(p[i]); return p; }
  static int i(String s, int d) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return d; } }
  static long l(String s, long d) { try { return Long.parseLong(s.trim()); } catch (Exception e) { return d; } }
  static String q(String s) {
    StringBuilder b = new StringBuilder("\"");
    for (char c : (s == null ? "" : s).toCharArray()) { if (c == '"' || c == '\\') b.append('\\').append(c); else if (c == '\n') b.append("\\n"); else if (c < 32) b.append(' '); else b.append(c); }
    return b.append('"').toString();
  }
}
