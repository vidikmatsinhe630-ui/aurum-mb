package com.vidik.aurummb;

import java.net.*;
import javax.net.ssl.*;

/** Ligações ao servidor da Aurum que também funcionam em Android 5 (TLS 1.2 ligado) e erros que dizem a causa verdadeira. */
final class NetErr {
  private NetErr() { }
  private static SSLSocketFactory tls12;

  /** abre a ligação; em HTTPS usa TLS 1.2 explícito (Android 5.x antigo pode não o ligar sozinho) */
  static HttpURLConnection open(String url) throws Exception {
    HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
    if (h instanceof HttpsURLConnection) { try { SSLSocketFactory f = factory(); if (f != null) ((HttpsURLConnection) h).setSSLSocketFactory(f); } catch (Throwable t) { } }
    return h;
  }
  private static synchronized SSLSocketFactory factory() throws Exception {
    if (tls12 != null) return tls12;
    final SSLSocketFactory base = baseFactory();
    tls12 = new SSLSocketFactory() {
      Socket on(Socket s) { if (s instanceof SSLSocket) { try { SSLSocket x = (SSLSocket) s; java.util.List<String> p = new java.util.ArrayList<>(); for (String q : x.getSupportedProtocols()) if (q.equals("TLSv1.2") || q.equals("TLSv1.3") || q.equals("TLSv1.1") || q.equals("TLSv1")) p.add(q); if (!p.isEmpty()) x.setEnabledProtocols(p.toArray(new String[0])); } catch (Throwable t) { } } return s; }
      public String[] getDefaultCipherSuites() { return base.getDefaultCipherSuites(); }
      public String[] getSupportedCipherSuites() { return base.getSupportedCipherSuites(); }
      public Socket createSocket() throws java.io.IOException { return on(base.createSocket()); }
      public Socket createSocket(Socket s, String h, int p, boolean a) throws java.io.IOException { return on(base.createSocket(s, h, p, a)); }
      public Socket createSocket(String h, int p) throws java.io.IOException { return on(base.createSocket(h, p)); }
      public Socket createSocket(String h, int p, InetAddress l, int lp) throws java.io.IOException { return on(base.createSocket(h, p, l, lp)); }
      public Socket createSocket(InetAddress h, int p) throws java.io.IOException { return on(base.createSocket(h, p)); }
      public Socket createSocket(InetAddress h, int p, InetAddress l, int lp) throws java.io.IOException { return on(base.createSocket(h, p, l, lp)); }
    };
    return tls12;
  }

  /** TLS que confia nos certificados do telefone e, se o telefone não os conhece (Android 5/6 antigo), nos de raiz que vão dentro da app */
  private static SSLSocketFactory baseFactory() {
    try {
      final javax.net.ssl.X509TrustManager sys = pick(null);
      java.security.KeyStore ks = java.security.KeyStore.getInstance(java.security.KeyStore.getDefaultType()); ks.load(null, null);
      java.security.cert.CertificateFactory cf = java.security.cert.CertificateFactory.getInstance("X.509"); int i = 0;
      for (java.security.cert.Certificate c : cf.generateCertificates(new java.io.ByteArrayInputStream(CaPem.ALL.getBytes("US-ASCII")))) ks.setCertificateEntry("b" + (i++), c);
      final javax.net.ssl.X509TrustManager own = pick(ks);
      javax.net.ssl.X509TrustManager both = new javax.net.ssl.X509TrustManager() {
        public void checkClientTrusted(java.security.cert.X509Certificate[] c, String a) throws java.security.cert.CertificateException { sys.checkClientTrusted(c, a); }
        public void checkServerTrusted(java.security.cert.X509Certificate[] c, String a) throws java.security.cert.CertificateException { try { sys.checkServerTrusted(c, a); } catch (java.security.cert.CertificateException e) { own.checkServerTrusted(c, a); } }
        public java.security.cert.X509Certificate[] getAcceptedIssuers() { return sys.getAcceptedIssuers(); }
      };
      SSLContext ctx = SSLContext.getInstance("TLS"); ctx.init(null, new TrustManager[]{both}, null); return ctx.getSocketFactory();
    } catch (Throwable t) { return (SSLSocketFactory) SSLSocketFactory.getDefault(); }
  }
  private static javax.net.ssl.X509TrustManager pick(java.security.KeyStore ks) throws Exception {
    TrustManagerFactory f = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()); f.init(ks);
    for (TrustManager t : f.getTrustManagers()) if (t instanceof javax.net.ssl.X509TrustManager) return (javax.net.ssl.X509TrustManager) t;
    throw new IllegalStateException("sem TrustManager");
  }

  /** texto para o utilizador com a causa mais provável (sem esconder o erro verdadeiro) */
  static String why(Throwable e) {
    Throwable r = e; int n = 0; while (r.getCause() != null && r.getCause() != r && n++ < 6) r = r.getCause();
    String k = r.getClass().getSimpleName(), m = String.valueOf(r.getMessage()); if (m.length() > 90) m = m.substring(0, 90);
    String all = (e.getClass().getName() + " " + r.getClass().getName() + " " + m).toLowerCase(java.util.Locale.ROOT);
    String tip;
    if (all.contains("certpath") || all.contains("certificate") || all.contains("trust anchor") || all.contains("handshake") || all.contains("ssl") || all.contains("protocol")) {
      int yr = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);
      tip = (yr < 2025 ? "A data do telemóvel está errada (" + yr + "). Ligue a data e hora automáticas. " : "") + "O telemóvel não aceitou a segurança do servidor. Atualize a app e tente outra vez; se continuar, envie esta mensagem ao suporte.";
    }
    else if (all.contains("unknownhost") || all.contains("unable to resolve")) tip = "Não encontrei o servidor. Veja se os dados móveis ou o Wi-Fi têm internet.";
    else if (all.contains("timeout") || all.contains("timed out")) tip = "A ligação demorou demais. Tente outra vez com melhor rede.";
    else if (all.contains("connect") || all.contains("refused") || all.contains("unreachable") || all.contains("network")) tip = "Não consegui ligar ao servidor. Veja a internet e tente outra vez.";
    else tip = "Falhou a ligação. Tente outra vez.";
    return tip + " [" + k + (m.equals("null") || m.isEmpty() ? "" : ": " + m) + "]";
  }
}
