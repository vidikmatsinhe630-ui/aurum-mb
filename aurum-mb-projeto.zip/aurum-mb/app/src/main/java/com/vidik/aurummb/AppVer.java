package com.vidik.aurummb;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.*;
import java.net.*;
import org.json.*;

/** Atualização obrigatória: o dono publica no painel do servidor a versão nova e o link do APK. Quem não atualiza recebe aviso
 *  todos os dias e, passados 3 dias da publicação, fica bloqueado até instalar a versão nova. */
final class AppVer {
  private AppVer() { }
  static final int CODE = 26; static final String NAME = "1.9.6";
  private static SharedPreferences sp(Context c) { return c.getSharedPreferences("aurummb", 0); }

  /** vai buscar a versão publicada; sem internet fica com a última que soube */
  static void check(Context c) {
    try {
      HttpURLConnection h = NetErr.open(MbRelay.BASE + "/app/versao?app=mb");
      h.setConnectTimeout(8000); h.setReadTimeout(15000);
      if (h.getResponseCode() != 200) { h.disconnect(); return; }
      ByteArrayOutputStream o = new ByteArrayOutputStream(); InputStream in = h.getInputStream(); byte[] b = new byte[4096]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); h.disconnect();
      JSONObject j = new JSONObject(o.toString("UTF-8"));
      long srv = j.optLong("now", System.currentTimeMillis());
      sp(c).edit().putInt("av_code", j.optInt("code", 0)).putString("av_nome", j.optString("nome")).putString("av_link", j.optString("link")).putString("av_msg", j.optString("msg"))
        .putLong("av_limite", j.optLong("limite", 0)).putLong("av_off", srv - System.currentTimeMillis()).apply();
    } catch (Throwable t) { }
    apply(c);
  }
  static boolean outdated(Context c) { int v = sp(c).getInt("av_code", 0); return v > CODE; }
  /** o prazo (3 dias) já acabou? */
  static boolean mustBlock(Context c) {
    if (!outdated(c)) return false;
    long lim = sp(c).getLong("av_limite", 0); if (lim <= 0) return false;
    return System.currentTimeMillis() + sp(c).getLong("av_off", 0) >= lim;
  }
  static void apply(Context c) { try { MbHub.get(c).setBlkVer(mustBlock(c)); MbHub.notifyUi(); } catch (Throwable t) { } }
  /** {"old":bool,"block":bool,"nome":"","link":"","msg":"","days":N,"mine":"1.9.0"} */
  static String info(Context c) {
    SharedPreferences p = sp(c); boolean old = outdated(c); long left = 0;
    if (old) { long lim = p.getLong("av_limite", 0); left = lim - (System.currentTimeMillis() + p.getLong("av_off", 0)); }
    int days = left <= 0 ? 0 : (int) ((left + 86399999L) / 86400000L);
    return "{\"old\":" + old + ",\"block\":" + mustBlock(c) + ",\"nome\":" + Codec.q(p.getString("av_nome", "")) + ",\"link\":" + Codec.q(p.getString("av_link", "")) + ",\"msg\":" + Codec.q(p.getString("av_msg", "")) + ",\"days\":" + days + ",\"mine\":" + Codec.q(NAME) + "}";
  }
}
