package com.vidik.aurummb;

import android.accessibilityservice.AccessibilityService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;

/** Responde sozinha aos menus USSD da operadora (ex.: *162# > 8 > 2 > megas > número). Lê a janela do USSD, escreve o passo certo e toca em Enviar.
 *  Só mexe na janela do telefone enquanto há uma transferência a correr. */
public class UssdAccess extends AccessibilityService {
  static volatile UssdAccess inst;
  static volatile Session cur;
  static final Handler H = new Handler(Looper.getMainLooper());

  static final class Session { String[] steps; int idx; MbEngine.Cb cb; String lastMsg = ""; long lastAct, lastLoad, began; int retry; boolean done; boolean saw; String seen = ""; }
  static void note(Session s, String x) { if (s.seen.length() < 400 && !s.seen.contains(x)) s.seen += (s.seen.isEmpty() ? "" : "; ") + x; }

  /** começa a seguir os passos. false se o serviço de Acessibilidade não está ligado. */
  static boolean begin(String[] steps, MbEngine.Cb cb) {
    if (inst == null) return false;
    final Session s = new Session(); s.steps = steps; s.cb = cb; s.began = System.currentTimeMillis(); cur = s;
    H.postDelayed(new Runnable() { public void run() { if (cur == s && !s.done && !s.saw) finish(s, 1, "não vi a janela do USSD abrir (" + (s.seen.isEmpty() ? "nenhuma janela lida" : "vi: " + s.seen) + "). Veja se o USSD abre no telemóvel e se a Acessibilidade da Aurum MB está ligada", true); } }, 15000);
    H.postDelayed(new Runnable() { public void run() { if (cur == s && !s.done) finish(s, 1, "tempo esgotado a falar com a operadora" + (s.seen.isEmpty() ? "" : " (vi: " + s.seen + ")") + (s.idx < s.steps.length ? "; faltaram os passos a partir de \"" + s.steps[s.idx] + "\"" : ""), true); } }, 90000);
    return true;
  }
  static void finish(Session s, int status, String text, boolean close) {
    if (s.done) return; s.done = true; if (cur == s) cur = null;
    if (close && inst != null) inst.performGlobalAction(GLOBAL_ACTION_BACK);
    s.cb.done(status, text);
  }

  public void onServiceConnected() { inst = this; }
  public boolean onUnbind(android.content.Intent i) { inst = null; return super.onUnbind(i); }
  public void onInterrupt() { }

  static boolean known(String pkg) { return UssdText.known(pkg); }
  static boolean loading(String msg, boolean hasEdit) { return UssdText.loading(msg, hasEdit); }

  public void onAccessibilityEvent(AccessibilityEvent e) {
    final Session s = cur; if (s == null || s.done || e == null) return;
    AccessibilityNodeInfo root = null; StringBuilder text = new StringBuilder(); List<AccessibilityNodeInfo> edits = new ArrayList<>(), btns = new ArrayList<>();
    List<AccessibilityNodeInfo> roots = new ArrayList<>();
    try { List<android.view.accessibility.AccessibilityWindowInfo> ws = getWindows(); if (ws != null) for (android.view.accessibility.AccessibilityWindowInfo w : ws) { AccessibilityNodeInfo r = w.getRoot(); if (r != null) roots.add(r); } } catch (Throwable t) { }
    try { AccessibilityNodeInfo a = getRootInActiveWindow(); if (a != null) roots.add(a); } catch (Throwable t) { }
    // 1.º as janelas de pacotes conhecidos do telefone; 2.º qualquer janela alheia que tenha uma caixa de escrever e um botão (alguns fabricantes usam outro pacote)
    for (AccessibilityNodeInfo r : roots) { String pk = String.valueOf(r.getPackageName()); note(s, pk); if (known(pk)) { root = r; break; } }
    if (root == null) for (AccessibilityNodeInfo r : roots) { String pk = String.valueOf(r.getPackageName()); if (UssdText.foreign(pk)) { StringBuilder t2 = new StringBuilder(); List<AccessibilityNodeInfo> e2 = new ArrayList<>(), b2 = new ArrayList<>(); walk(r, t2, e2, b2); if (!e2.isEmpty() && !b2.isEmpty()) { root = r; break; } } }
    if (root == null) return;
    s.saw = true;
    walk(root, text, edits, btns);
    String msg = text.toString().trim();
    if (msg.isEmpty() && edits.isEmpty()) return;
    if (loading(msg, !edits.isEmpty())) { s.lastLoad = System.currentTimeMillis(); return; }   // espera: a janela volta a mudar quando a operadora responder
    long now = System.currentTimeMillis(); if (msg.equals(s.lastMsg) && now - s.lastAct < 1500) return;
    s.lastMsg = msg; s.lastAct = now;
    if (!edits.isEmpty() && s.idx < s.steps.length) {
      final AccessibilityNodeInfo box = edits.get(0); final String val = s.steps[s.idx++];
      fill(box, val);
      final String typed = val;
      H.postDelayed(new Runnable() { public void run() { verifyFilled(box, typed); click(freshButtons(), true); } }, 500);
      final long actAt = s.lastAct;   // se a janela não mudou passados 4 s, o toque falhou: repete (só o toque e a escrita, nunca avança um passo)
      H.postDelayed(new Runnable() { public void run() { if (cur == s && !s.done && s.lastAct == actAt && s.retry < 3) { s.retry++; verifyFilled(box, typed); click(freshButtons(), true); } } }, 3500);
      return;
    }
    // acabaram os passos: o que está no ecrã é a resposta final
    AccessibilityNodeInfo close = find(btns, edits.isEmpty() ? new String[]{"ok", "fechar", "close", "cancelar", "cancel", "dispensar", "dismiss"} : new String[]{"cancelar", "cancel"});
    if (close != null) close.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    finish(s, 0, msg, close == null);
  }

  /** escreve o passo na caixa: primeiro por texto direto, se falhar por colar */
  static void fill(AccessibilityNodeInfo box, String val) {
    try { box.performAction(AccessibilityNodeInfo.ACTION_FOCUS); } catch (Throwable t) { }
    Bundle a = new Bundle(); a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, val);
    boolean ok = false; try { ok = box.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a); } catch (Throwable t) { }
    if (!ok && inst != null) { try { android.content.ClipboardManager cm = (android.content.ClipboardManager) inst.getSystemService(android.content.Context.CLIPBOARD_SERVICE); cm.setPrimaryClip(android.content.ClipData.newPlainText("ussd", val)); box.performAction(AccessibilityNodeInfo.ACTION_PASTE); } catch (Throwable t) { } }
  }
  /** toca no botão de enviar; se não o encontra pelo nome, no botão que não é "cancelar" */
  static void click(List<AccessibilityNodeInfo> btns, boolean send) {
    AccessibilityNodeInfo b = find(btns, "enviar", "send", "ok", "responder", "reply", "seguinte", "next");
    if (b == null) for (AccessibilityNodeInfo x : btns) { String t = label(x); if (!t.contains("cancel") && !t.contains("fechar") && !t.contains("close") && x.isEnabled()) { b = x; break; } }
    if (b != null) { try { b.refresh(); } catch (Throwable t) { } b.performAction(AccessibilityNodeInfo.ACTION_CLICK); }
  }

  static boolean isEdit(AccessibilityNodeInfo n) { String c = String.valueOf(n.getClassName()); return c.endsWith("EditText") || c.contains("EditText") || (n.isEditable() && !c.contains("Button")); }
  static boolean isBtn(AccessibilityNodeInfo n) {
    String c = String.valueOf(n.getClassName()); if (c.contains("Button")) return true;
    if (n.isClickable() && !isEdit(n) && !c.contains("TextView") ) { CharSequence t = n.getText() != null ? n.getText() : n.getContentDescription(); return t != null && t.length() > 0 && t.length() < 24; }
    return false;
  }
  static void walk(AccessibilityNodeInfo n, StringBuilder text, List<AccessibilityNodeInfo> edits, List<AccessibilityNodeInfo> btns) {
    if (n == null) return;
    String c = String.valueOf(n.getClassName());
    if (isEdit(n)) edits.add(n);
    else if (isBtn(n)) btns.add(n);
    else if (n.getText() != null && n.getText().length() > 0 && (c.contains("TextView") || !n.isClickable())) { if (text.length() > 0) text.append('\n'); text.append(n.getText()); }
    for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), text, edits, btns);
  }
  /** os botões da janela do USSD tal como estão agora (os guardados podem ter ficado velhos) */
  static List<AccessibilityNodeInfo> freshButtons() {
    List<AccessibilityNodeInfo> b = new ArrayList<>(); UssdAccess u = inst; if (u == null) return b;
    try { List<android.view.accessibility.AccessibilityWindowInfo> ws = u.getWindows(); if (ws != null) for (android.view.accessibility.AccessibilityWindowInfo w : ws) { AccessibilityNodeInfo r = w.getRoot(); if (r != null && (known(String.valueOf(r.getPackageName())) || UssdText.foreign(String.valueOf(r.getPackageName())))) { List<AccessibilityNodeInfo> e = new ArrayList<>(); walk(r, new StringBuilder(), e, b); if (!b.isEmpty() && !e.isEmpty()) return b; b.clear(); } } } catch (Throwable t) { }
    try { AccessibilityNodeInfo r = u.getRootInActiveWindow(); if (r != null) walk(r, new StringBuilder(), new ArrayList<AccessibilityNodeInfo>(), b); } catch (Throwable t) { }
    return b;
  }
  /** se a caixa ficou vazia, tenta escrever outra vez por outro caminho */
  static void verifyFilled(AccessibilityNodeInfo box, String val) {
    try { box.refresh(); CharSequence t = box.getText(); if (t != null && t.toString().trim().equals(val)) return; } catch (Throwable x) { }
    fill(box, val);
  }
  static String label(AccessibilityNodeInfo b) { CharSequence t = b.getText() != null ? b.getText() : b.getContentDescription(); return t == null ? "" : t.toString().trim().toLowerCase(); }
  static AccessibilityNodeInfo find(List<AccessibilityNodeInfo> btns, String... names) {
    for (AccessibilityNodeInfo b : btns) { String t = label(b); for (String x : names) if (t.equals(x)) return b; }
    for (AccessibilityNodeInfo b : btns) { String t = label(b); for (String x : names) if (x.length() > 2 && t.contains(x)) return b; }
    return null;
  }

  /** o serviço está ligado nas definições de Acessibilidade? */
  static boolean enabled(android.content.Context c) {
    try { String v = android.provider.Settings.Secure.getString(c.getContentResolver(), android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES); return v != null && v.contains(c.getPackageName() + "/"); } catch (Exception e) { return false; }
  }
}
