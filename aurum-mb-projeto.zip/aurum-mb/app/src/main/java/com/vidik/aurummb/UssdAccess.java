package com.vidik.aurummb;

import android.accessibilityservice.AccessibilityService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;

/** Responde sozinha aos menus USSD da operadora (ex.: *162# > 8 > 2 > megas > número). Lê a janela do USSD, escreve o passo certo e toca em Enviar.
 *  Só mexe na janela do telefone enquanto há uma transferência a correr. */
public class UssdAccess extends AccessibilityService {
  static volatile UssdAccess inst;
  static volatile Session cur;
  static final Handler H = new Handler(Looper.getMainLooper());

  static final class Session { String[] steps; int idx; MbEngine.Cb cb; String lastMsg = ""; long lastAct, lastLoad, began; int retry; boolean done; boolean saw; boolean slow; String seen = ""; }
  static void note(Session s, String x) { if (s.seen.length() < 400 && !s.seen.contains(x)) s.seen += (s.seen.isEmpty() ? "" : "; ") + x; }

  /** começa a seguir os passos. false se o serviço de Acessibilidade não está ligado. */
  static boolean begin(String[] steps, MbEngine.Cb cb) {
    if (inst == null) return false;
    final Session s = new Session(); s.steps = steps; s.cb = cb; s.began = System.currentTimeMillis(); cur = s;
    H.postDelayed(new Runnable() { public void run() { if (cur == s && !s.done && !s.saw) finish(s, 1, "não vi a janela do USSD abrir (" + (s.seen.isEmpty() ? "nenhuma janela lida" : "vi: " + s.seen) + "; " + describe() + "). Veja se o USSD abre no telemóvel e se a Acessibilidade da Aurum MB está ligada", true); } }, 30000);
    H.postDelayed(new Runnable() { public void run() { if (cur == s && !s.done) finish(s, 1, "tempo esgotado a falar com a operadora" + (s.seen.isEmpty() ? "" : " (vi: " + s.seen + ")") + (s.idx < s.steps.length ? "; faltaram os passos a partir de \"" + s.steps[s.idx] + "\"" : ""), true); } }, 150000);
    // telemóveis fracos deixam cair eventos: além dos eventos, olha para a janela de 1,2 em 1,2 segundos
    H.postDelayed(new Runnable() { public void run() { if (cur != s || s.done) return; UssdAccess u = inst; if (u != null) { try { u.process(); } catch (Throwable t) { } } H.postDelayed(this, 1200); } }, 1200);
    return true;
  }
  static void finish(Session s, int status, String text, boolean close) {
    if (s.done) return; s.done = true; if (cur == s) cur = null;
    if (close && inst != null) inst.performGlobalAction(GLOBAL_ACTION_BACK);
    s.cb.done(status, text);
  }

  public void onServiceConnected() { inst = this; }
  public boolean onUnbind(android.content.Intent i) { inst = null; return super.onUnbind(i); }
  public void onInterrupt() { }

  static boolean known(String pkg) { return UssdText.known(pkg); }
  static boolean loading(String msg, boolean hasEdit) { return UssdText.loading(msg, hasEdit); }

  public void onAccessibilityEvent(AccessibilityEvent e) { if (e == null) return; try { process(); } catch (Throwable t) { } }

  /** olha para a janela do USSD e dá o passo seguinte, se for caso disso (chamado pelos eventos e pelo relógio) */
  void process() {
    final Session s = cur; if (s == null || s.done) return;
    AccessibilityNodeInfo root = null; StringBuilder text = new StringBuilder(); List<AccessibilityNodeInfo> edits = new ArrayList<>(), btns = new ArrayList<>();
    List<AccessibilityNodeInfo> roots = new ArrayList<>();
    try { List<android.view.accessibility.AccessibilityWindowInfo> ws = getWindows(); if (ws != null) for (android.view.accessibility.AccessibilityWindowInfo w : ws) { AccessibilityNodeInfo r = w.getRoot(); if (r != null) roots.add(r); } } catch (Throwable t) { }
    try { AccessibilityNodeInfo a = getRootInActiveWindow(); if (a != null) roots.add(a); } catch (Throwable t) { }
    // 1.º as janelas de pacotes conhecidos do telefone; 2.º qualquer janela alheia que tenha uma caixa de escrever e um botão (alguns fabricantes usam outro pacote)
    for (AccessibilityNodeInfo r : roots) { String pk = String.valueOf(r.getPackageName()); note(s, pk); if (known(pk)) { root = r; break; } }
    if (root == null) for (AccessibilityNodeInfo r : roots) { String pk = String.valueOf(r.getPackageName()); if (UssdText.foreign(pk)) { StringBuilder t2 = new StringBuilder(); List<AccessibilityNodeInfo> e2 = new ArrayList<>(), b2 = new ArrayList<>(); walk(r, t2, e2, b2); if (!e2.isEmpty() && !b2.isEmpty()) { root = r; break; } } }
    if (root == null) return;
    s.saw = true;
    walk(root, text, edits, btns);
    String msg = text.toString().trim();
    if (msg.isEmpty() && edits.isEmpty()) return;
    if (loading(msg, !edits.isEmpty())) { s.lastLoad = System.currentTimeMillis(); s.lastMsg = ""; return; }   // espera: a janela volta a mudar quando a operadora responder
    long now = System.currentTimeMillis();
    // a mesma janela que já respondemos: não escreve outro passo por cima (telemóveis lentos ainda mostram o menu antigo); só o toque repetido abaixo trata disso
    if (msg.equals(s.lastMsg) && now - s.lastAct < 12000) return;
    s.lastMsg = msg; s.lastAct = now;
    if (!edits.isEmpty() && s.idx < s.steps.length) {
      final String val = s.steps[s.idx++];
      final long d1 = s.slow ? 700 : 350, d2 = s.slow ? 1500 : 800;   // escrever, conferir, só depois enviar
      fill(freshEdit(edits.get(0)), val);
      H.postDelayed(new Runnable() { public void run() { if (cur == s && !s.done) verifyFilled(freshEdit(null), val); } }, d1);
      H.postDelayed(new Runnable() { public void run() { if (cur == s && !s.done) sendAttempt(1, val); } }, d2);
      final long actAt = s.lastAct;   // se a janela não mudou, o toque falhou: repete a escrita e o toque (nunca avança um passo)
      scheduleRetry(s, actAt, val, s.slow ? 6000 : 4000);
      return;
    }
    // ainda faltam passos mas a janela não tem caixa de escrever: é uma confirmação (OK / Enviar / Confirmar). Carrega e continua; se for um erro da operadora, termina com ele.
    if (edits.isEmpty() && s.idx < s.steps.length) {
      if (UssdText.midError(msg)) { AccessibilityNodeInfo c0 = find(btns, "ok", "fechar", "close", "dispensar", "dismiss"); if (c0 != null) clickDeep(c0); finish(s, 0, msg, c0 == null); return; }
      AccessibilityNodeInfo go = null; for (AccessibilityNodeInfo b : btns) { if (UssdText.continueLabel(label(b))) { go = b; break; } }
      if (go != null) { final long actAt2 = s.lastAct; try { go.refresh(); } catch (Throwable t) { } clickDeep(go); scheduleConfirmRetry(s, actAt2, s.slow ? 6000 : 4000); return; }
    }
    // acabaram os passos: o que está no ecrã é a resposta final
    AccessibilityNodeInfo close = find(btns, edits.isEmpty() ? new String[]{"ok", "fechar", "close", "cancelar", "cancel", "dispensar", "dismiss"} : new String[]{"cancelar", "cancel"});
    if (close != null) clickDeep(close);
    finish(s, 0, msg, close == null);
  }

  static void scheduleRetry(final Session s, final long actAt, final String val, final long wait) {
    H.postDelayed(new Runnable() { public void run() {
      if (cur != s || s.done || s.lastAct != actAt) return;   // a janela mudou: tudo bem
      s.slow = true; s.retry++;
      if (s.retry > 4) { finish(s, 1, "o telemóvel não aceitou o passo \"" + val + "\" na janela do USSD (tentei 4 vezes). Janela: " + describe(), true); return; }
      sendAttempt(s.retry, val);
      scheduleRetry(s, actAt, val, wait + 2000);
    } }, wait);
  }
  /** a janela de confirmação não mudou: carrega outra vez no botão (no máximo 4 vezes) */
  static void scheduleConfirmRetry(final Session s, final long actAt, final long wait) {
    H.postDelayed(new Runnable() { public void run() {
      if (cur != s || s.done || s.lastAct != actAt) return;
      s.slow = true; s.retry++;
      if (s.retry > 4) { finish(s, 1, "o telemóvel não avançou na confirmação do USSD (tentei 4 vezes). Janela: " + describe(), true); return; }
      List<AccessibilityNodeInfo> b = freshButtons(); AccessibilityNodeInfo go = null; for (AccessibilityNodeInfo x : b) { if (UssdText.continueLabel(label(x))) { go = x; break; } }
      if (go != null) { clickDeep(go); if (s.retry >= 2) tap(go); }
      scheduleConfirmRetry(s, actAt, wait + 2000);
    } }, wait);
  }
  /** a caixa de escrever tal como está agora (a guardada pode ter ficado velha num telemóvel lento) */
  static AccessibilityNodeInfo freshEdit(AccessibilityNodeInfo old) {
    UssdAccess u = inst; if (u == null) return old;
    try { List<android.view.accessibility.AccessibilityWindowInfo> ws = u.getWindows(); if (ws != null) for (android.view.accessibility.AccessibilityWindowInfo w : ws) { AccessibilityNodeInfo r = w.getRoot(); if (r != null && (known(String.valueOf(r.getPackageName())) || UssdText.foreign(String.valueOf(r.getPackageName())))) { List<AccessibilityNodeInfo> e = new ArrayList<>(); walk(r, new StringBuilder(), e, new ArrayList<AccessibilityNodeInfo>()); if (!e.isEmpty()) return e.get(0); } } } catch (Throwable t) { }
    try { AccessibilityNodeInfo r = u.getRootInActiveWindow(); if (r != null) { List<AccessibilityNodeInfo> e = new ArrayList<>(); walk(r, new StringBuilder(), e, new ArrayList<AccessibilityNodeInfo>()); if (!e.isEmpty()) return e.get(0); } } catch (Throwable t) { }
    return old;
  }

  /** escreve o passo na caixa: primeiro por texto direto, se falhar por colar */
  static void fill(AccessibilityNodeInfo box, String val) {
    if (box == null) return;
    try { box.performAction(AccessibilityNodeInfo.ACTION_CLICK); } catch (Throwable t) { }
    try { box.performAction(AccessibilityNodeInfo.ACTION_FOCUS); } catch (Throwable t) { }
    Bundle a = new Bundle(); a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, val);
    boolean ok = false; try { ok = box.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a); } catch (Throwable t) { }
    if (ok && textIs(box, val)) return;
    // caminho 2: limpa e escreve outra vez (alguns telefones só aceitam à segunda)
    try { Bundle e = new Bundle(); e.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, ""); box.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, e); box.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a); } catch (Throwable t) { }
    if (textIs(box, val)) return;
    // caminho 3: colar (seleciona tudo e cola por cima)
    if (inst != null) { try {
      android.content.ClipboardManager cm = (android.content.ClipboardManager) inst.getSystemService(android.content.Context.CLIPBOARD_SERVICE); cm.setPrimaryClip(android.content.ClipData.newPlainText("ussd", val));
      try { Bundle sel = new Bundle(); sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0); sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, 100); box.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel); } catch (Throwable t) { }
      box.performAction(AccessibilityNodeInfo.ACTION_PASTE);
    } catch (Throwable t) { } }
  }
  /** o texto que a caixa mostra agora é exatamente este? (a "dica" cinzenta da caixa vazia não conta) */
  static boolean textIs(AccessibilityNodeInfo box, String val) {
    try { box.refresh(); CharSequence t = box.getText(); return t != null && t.toString().trim().equals(val); } catch (Throwable x) { return false; }
  }
  /** o botão de enviar da janela: pelo nome ou, se não o encontra, o primeiro que não é "cancelar" */
  static AccessibilityNodeInfo pickSend(List<AccessibilityNodeInfo> btns) {
    AccessibilityNodeInfo b = find(btns, "enviar", "send", "ok", "responder", "reply", "seguinte", "next");
    if (b == null) for (AccessibilityNodeInfo x : btns) { String t = label(x); if (!t.contains("cancel") && !t.contains("fechar") && !t.contains("close") && x.isEnabled()) { b = x; break; } }
    return b;
  }
  /** toca no botão de enviar */
  static void click(List<AccessibilityNodeInfo> btns, boolean send) {
    AccessibilityNodeInfo b = pickSend(btns);
    if (b != null) { try { b.refresh(); } catch (Throwable t) { } clickDeep(b); }
  }
  /** toque no ecrã por cima do botão (para telemóveis, como alguns Samsung, onde o clique do botão não faz nada) */
  static boolean tap(AccessibilityNodeInfo n) {
    try {
      UssdAccess u = inst; if (u == null || n == null || android.os.Build.VERSION.SDK_INT < 24) return false;
      android.graphics.Rect r = new android.graphics.Rect(); n.getBoundsInScreen(r); if (r.isEmpty()) return false;
      android.graphics.Path p = new android.graphics.Path(); p.moveTo(r.centerX(), r.centerY());
      android.accessibilityservice.GestureDescription.Builder g = new android.accessibilityservice.GestureDescription.Builder();
      g.addStroke(new android.accessibilityservice.GestureDescription.StrokeDescription(p, 0, 80));
      return u.dispatchGesture(g.build(), null, null);
    } catch (Throwable t) { return false; }
  }
  /** a tecla "enviar" do teclado, pela caixa de escrever (Android 11 ou mais) */
  static boolean imeEnter(AccessibilityNodeInfo box) {
    try { return box != null && android.os.Build.VERSION.SDK_INT >= 30 && box.performAction(16908372); } catch (Throwable t) { return false; }   // ACTION_IME_ENTER
  }
  /** tentativa n (1, 2, 3, 4...) de enviar o passo: cada vez por um caminho diferente */
  static void sendAttempt(int n, String val) {
    AccessibilityNodeInfo box = freshEdit(null); verifyFilled(box, val);
    List<AccessibilityNodeInfo> bs = freshButtons(); AccessibilityNodeInfo b = pickSend(bs);
    if (n == 1) { click(bs, true); }
    else if (n == 2) { if (!imeEnter(box)) click(bs, true); }
    else if (n == 3) { if (!tap(b)) click(bs, true); }
    else { click(bs, true); tap(b); imeEnter(box); }
  }
  /** descrição curta da janela do USSD (vai para o erro, para eu ver o que o telemóvel mostra) */
  static String describe() {
    try {
      UssdAccess u = inst; if (u == null) return "sem serviço";
      List<AccessibilityNodeInfo> roots = new ArrayList<>(); List<android.view.accessibility.AccessibilityWindowInfo> ws = u.getWindows(); if (ws != null) for (android.view.accessibility.AccessibilityWindowInfo w : ws) { AccessibilityNodeInfo r = w.getRoot(); if (r != null) roots.add(r); }
      for (AccessibilityNodeInfo r : roots) { String pk = String.valueOf(r.getPackageName()); if (!(known(pk) || UssdText.foreign(pk))) continue;
        StringBuilder t = new StringBuilder(); List<AccessibilityNodeInfo> e = new ArrayList<>(), b = new ArrayList<>(); walk(r, t, e, b);
        if (e.isEmpty() && b.isEmpty() && t.length() == 0) continue;
        StringBuilder o = new StringBuilder(pk).append(": caixas=").append(e.size()).append(" botões=["); for (int i = 0; i < b.size() && i < 5; i++) { if (i > 0) o.append(','); o.append(label(b.get(i))); }
        String m = t.toString().replace('\n', ' '); if (m.length() > 70) m = m.substring(0, 70);
        o.append("] texto=").append(m).append(" árvore=["); StringBuilder tr = new StringBuilder(); tree(r, tr, 0); return o.append(tr).append("]").toString(); }
    } catch (Throwable x) { }
    return "nenhuma janela do telefone";
  }
  /** classe, se aceita clique e o texto de cada nó (o que o telemóvel realmente mostra) */
  static void tree(AccessibilityNodeInfo n, StringBuilder o, int d) {
    if (n == null || d > 9 || o.length() > 700) return;
    String c = String.valueOf(n.getClassName()); int k = c.lastIndexOf('.'); if (k >= 0) c = c.substring(k + 1);
    CharSequence tx = n.getText() != null ? n.getText() : n.getContentDescription(); String ts = tx == null ? "" : tx.toString().replace('\n', ' '); if (ts.length() > 18) ts = ts.substring(0, 18);
    if (o.length() > 0) o.append(" | "); o.append(c).append(n.isClickable() ? "*" : "").append(ts.isEmpty() ? "" : ":" + ts);
    for (int i = 0; i < n.getChildCount(); i++) tree(n.getChild(i), o, d + 1);
  }

  static boolean isEdit(AccessibilityNodeInfo n) { String c = String.valueOf(n.getClassName()); return c.endsWith("EditText") || c.contains("EditText") || (n.isEditable() && !c.contains("Button")); }
  static boolean isBtn(AccessibilityNodeInfo n) {
    String c = String.valueOf(n.getClassName()); if (c.contains("Button")) return true;
    CharSequence t = n.getText() != null ? n.getText() : n.getContentDescription();
    if (t == null || t.length() == 0 || t.length() >= 24 || isEdit(n)) return false;
    // alguns telefones (OPPO/ColorOS, Android 8) desenham o botão como texto clicável, ou nem o marcam como clicável
    if (n.isClickable()) return true;
    return UssdText.sendLabel(t.toString());
  }
  /** carrega no nó; se ele não aceita o clique, sobe aos pais até um que aceite (o botão pode ser só o texto dentro de uma caixa clicável) */
  static boolean clickDeep(AccessibilityNodeInfo n) {
    AccessibilityNodeInfo x = n; boolean ok = false;
    for (int i = 0; i < 5 && x != null; i++) {
      try { if (i == 0 || x.isClickable()) { ok = x.performAction(AccessibilityNodeInfo.ACTION_CLICK); if (ok && i > 0) return true; if (ok && x.isClickable()) return true; } } catch (Throwable t) { }
      try { x = x.getParent(); } catch (Throwable t) { x = null; }
    }
    return ok;
  }
  static void walk(AccessibilityNodeInfo n, StringBuilder text, List<AccessibilityNodeInfo> edits, List<AccessibilityNodeInfo> btns) {
    if (n == null) return;
    String c = String.valueOf(n.getClassName());
    if (isEdit(n)) edits.add(n);
    else if (isBtn(n)) btns.add(n);
    else if (n.getText() != null && n.getText().length() > 0 && (c.contains("TextView") || !n.isClickable())) { if (text.length() > 0) text.append('\n'); text.append(n.getText()); }
    for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), text, edits, btns);
  }
  /** os botões da janela do USSD tal como estão agora (os guardados podem ter ficado velhos) */
  static List<AccessibilityNodeInfo> freshButtons() {
    List<AccessibilityNodeInfo> b = new ArrayList<>(); UssdAccess u = inst; if (u == null) return b;
    try { List<android.view.accessibility.AccessibilityWindowInfo> ws = u.getWindows(); if (ws != null) for (android.view.accessibility.AccessibilityWindowInfo w : ws) { AccessibilityNodeInfo r = w.getRoot(); if (r != null && (known(String.valueOf(r.getPackageName())) || UssdText.foreign(String.valueOf(r.getPackageName())))) { List<AccessibilityNodeInfo> e = new ArrayList<>(); walk(r, new StringBuilder(), e, b); if (!b.isEmpty() && !e.isEmpty()) return b; b.clear(); } } } catch (Throwable t) { }
    try { AccessibilityNodeInfo r = u.getRootInActiveWindow(); if (r != null) walk(r, new StringBuilder(), new ArrayList<AccessibilityNodeInfo>(), b); } catch (Throwable t) { }
    return b;
  }
  /** se a caixa ficou vazia, tenta escrever outra vez por outro caminho */
  static void verifyFilled(AccessibilityNodeInfo box, String val) {
    if (box == null) return;
    if (textIs(box, val)) return;
    fill(box, val);
  }
  static String label(AccessibilityNodeInfo b) { CharSequence t = b.getText() != null ? b.getText() : b.getContentDescription(); return t == null ? "" : t.toString().trim().toLowerCase(); }
  static AccessibilityNodeInfo find(List<AccessibilityNodeInfo> btns, String... names) {
    for (AccessibilityNodeInfo b : btns) { String t = label(b); for (String x : names) if (t.equals(x)) return b; }
    for (AccessibilityNodeInfo b : btns) { String t = label(b); for (String x : names) if (x.length() > 2 && t.contains(x)) return b; }
    return null;
  }

  /** o serviço está ligado nas definições de Acessibilidade? */
  static boolean enabled(android.content.Context c) {
    try { String v = android.provider.Settings.Secure.getString(c.getContentResolver(), android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES); return v != null && v.contains(c.getPackageName() + "/"); } catch (Exception e) { return false; }
  }
}
