package com.vidik.aurummb;

import android.accessibilityservice.AccessibilityService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;

/** Responde sozinha aos menus USSD da operadora (ex.: *162# > 8 > 2 > megas > número). Lê a janela do USSD, escreve o passo certo e toca em Enviar.
 *  Só mexe na janela do telefone enquanto há uma transferência a correr. */
public class UssdAccess extends AccessibilityService {
  static volatile UssdAccess inst;
  static volatile Session cur;
  static final Handler H = new Handler(Looper.getMainLooper());

  static final class Session { String[] steps; int idx; MbEngine.Cb cb; String lastMsg = ""; long lastAct; boolean done; }

  /** começa a seguir os passos. false se o serviço de Acessibilidade não está ligado. */
  static boolean begin(String[] steps, MbEngine.Cb cb) {
    if (inst == null) return false;
    final Session s = new Session(); s.steps = steps; s.cb = cb; cur = s;
    H.postDelayed(new Runnable() { public void run() { if (cur == s && !s.done) finish(s, 1, "tempo esgotado a falar com a operadora", true); } }, 60000);
    return true;
  }
  static void finish(Session s, int status, String text, boolean close) {
    if (s.done) return; s.done = true; if (cur == s) cur = null;
    if (close && inst != null) inst.performGlobalAction(GLOBAL_ACTION_BACK);
    s.cb.done(status, text);
  }

  public void onServiceConnected() { inst = this; }
  public boolean onUnbind(android.content.Intent i) { inst = null; return super.onUnbind(i); }
  public void onInterrupt() { }

  public void onAccessibilityEvent(AccessibilityEvent e) {
    final Session s = cur; if (s == null || s.done || e == null) return;
    String pkg = String.valueOf(e.getPackageName()).toLowerCase();
    if (!(pkg.contains("phone") || pkg.contains("telecom") || pkg.contains("dialer") || pkg.contains("incallui"))) return;
    AccessibilityNodeInfo root = getRootInActiveWindow(); if (root == null) return;
    StringBuilder text = new StringBuilder(); List<AccessibilityNodeInfo> edits = new ArrayList<>(), btns = new ArrayList<>();
    walk(root, text, edits, btns);
    String msg = text.toString().trim(); String low = msg.toLowerCase();
    if (msg.isEmpty() || low.contains("a executar") || low.contains("running") || low.contains("ussd code")) return;   // janela de "a executar código USSD"
    long now = System.currentTimeMillis(); if (msg.equals(s.lastMsg) && now - s.lastAct < 1500) return;
    s.lastMsg = msg; s.lastAct = now;
    if (!edits.isEmpty() && s.idx < s.steps.length) {
      Bundle a = new Bundle(); a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s.steps[s.idx++]);
      edits.get(0).performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a);
      final AccessibilityNodeInfo send = find(btns, "enviar", "send", "ok", "responder", "reply");
      H.postDelayed(new Runnable() { public void run() { if (send != null) send.performAction(AccessibilityNodeInfo.ACTION_CLICK); } }, 300);
      return;
    }
    // acabaram os passos: o que está no ecrã é a resposta final
    AccessibilityNodeInfo close = find(btns, edits.isEmpty() ? new String[]{"ok", "fechar", "close"} : new String[]{"cancelar", "cancel"});
    if (close != null) close.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    finish(s, 0, msg, close == null);
  }

  static void walk(AccessibilityNodeInfo n, StringBuilder text, List<AccessibilityNodeInfo> edits, List<AccessibilityNodeInfo> btns) {
    if (n == null) return;
    String c = String.valueOf(n.getClassName());
    if (c.endsWith("EditText")) edits.add(n);
    else if (c.endsWith("Button")) btns.add(n);
    else if (c.endsWith("TextView") && n.getText() != null) { if (text.length() > 0) text.append('\n'); text.append(n.getText()); }
    for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), text, edits, btns);
  }
  static AccessibilityNodeInfo find(List<AccessibilityNodeInfo> btns, String... names) {
    for (AccessibilityNodeInfo b : btns) { String t = b.getText() == null ? "" : b.getText().toString().trim().toLowerCase(); for (String x : names) if (t.equals(x)) return b; }
    return null;
  }

  /** o serviço está ligado nas definições de Acessibilidade? */
  static boolean enabled(android.content.Context c) {
    try { String v = android.provider.Settings.Secure.getString(c.getContentResolver(), android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES); return v != null && v.contains(c.getPackageName() + "/"); } catch (Exception e) { return false; }
  }
}
