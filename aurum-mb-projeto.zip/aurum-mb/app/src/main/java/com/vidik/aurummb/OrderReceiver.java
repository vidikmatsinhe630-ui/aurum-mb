package com.vidik.aurummb;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Pedido da Aurum: id, phone, mb, mt, confirm e o código da ligação. Só entra quem tem a permissão (mesma assinatura) e o código certo. */
public class OrderReceiver extends BroadcastReceiver {
  public void onReceive(Context c, Intent i) {
    MbEngine e = MbHub.get(c); long now = System.currentTimeMillis();
    if (!e.codeOk(i.getStringExtra("code"))) { e.err(now, "Aurum", "Pedido ignorado: o código da ligação não confere.", "Ligue de novo a Aurum MB à Aurum.", ""); e.save(); MbHub.notifyUi(); return; }
    String r = e.submit(String.valueOf(i.getStringExtra("id")), String.valueOf(i.getStringExtra("phone")), i.getLongExtra("mb", 0), i.getLongExtra("mt", 0), i.getBooleanExtra("confirm", false), i.getBooleanExtra("cred", false), String.valueOf(i.getStringExtra("grp") == null ? "" : i.getStringExtra("grp")), String.valueOf(i.getStringExtra("gname") == null ? "" : i.getStringExtra("gname")), i.getBooleanExtra("sem", false), now);
    MbService.start(c); MbHub.notifyUi();
  }
}
