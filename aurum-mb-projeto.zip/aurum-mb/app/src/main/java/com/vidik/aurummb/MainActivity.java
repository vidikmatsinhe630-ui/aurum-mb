package com.vidik.aurummb;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
  WebView w;

  protected void onCreate(Bundle b) {
    super.onCreate(b);
    w = new WebView(this); w.setBackgroundColor(0xFF05070D);
    WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setSupportZoom(false); s.setBuiltInZoomControls(false); s.setTextZoom(100); s.setUseWideViewPort(false); s.setLoadWithOverviewMode(false);
    w.setWebViewClient(new WebViewClient());
    w.addJavascriptInterface(new Bridge(), "Android");
    setContentView(w);
    MbHub.ui = () -> push();
    w.loadUrl("file:///android_asset/ui.html");
    ask();
    MbService.start(this);
  }
  protected void onResume() { super.onResume(); MbHub.ui = () -> push(); screen(); push(); MbPay.resume(this); new Thread(() -> MbPay.sync(MainActivity.this)).start(); }
  protected void onPause() { super.onPause(); }

  void push() { runOnUiThread(() -> { if (w != null) w.evaluateJavascript("window.onMb&&onMb()", null); }); }
  void screen() { if (MbHub.get(this).sc) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); }

  /** pede as permissões que a app precisa: ligar/USSD, estado do telefone e avisos */
  void ask() {
    java.util.ArrayList<String> p = new java.util.ArrayList<>();
    if (Build.VERSION.SDK_INT < 23) return;   // Android 5.x: nada a pedir, as permissões vêm com a instalação
    if (!Perm.has(this, Manifest.permission.CALL_PHONE)) p.add(Manifest.permission.CALL_PHONE);
    if (!Perm.has(this, Manifest.permission.READ_PHONE_STATE)) p.add(Manifest.permission.READ_PHONE_STATE);
    if (Build.VERSION.SDK_INT >= 33 && !Perm.has(this, Manifest.permission.POST_NOTIFICATIONS)) p.add(Manifest.permission.POST_NOTIFICATIONS);
    if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), 1);
  }
  public void onRequestPermissionsResult(int r, String[] p, int[] g) { super.onRequestPermissionsResult(r, p, g); push(); }

  String perms() {
    boolean call = Perm.has(this, Manifest.permission.CALL_PHONE), ph = Perm.has(this, Manifest.permission.READ_PHONE_STATE);
    boolean bat = Perm.battery(this);
    return "{\"call\":" + call + ",\"phone\":" + ph + ",\"battery\":" + bat + ",\"acc\":" + UssdAccess.enabled(this) + ",\"aurum\":" + aurumInstalled() + "}";
  }
  boolean aurumInstalled() { try { getPackageManager().getPackageInfo(MbHub.AURUM_PKG, 0); return true; } catch (Exception e) { return false; } }

  class Bridge {
    @JavascriptInterface public String mb(String op, String arg) {
      try { return run(op, arg == null ? new String[0] : arg.split("\u0001", -1)); } catch (Exception e) { return "ERR:" + e.getMessage(); }
    }
    String run(String op, String[] a) {
      MbEngine e = MbHub.get(MainActivity.this); long now = System.currentTimeMillis();
      switch (op) {
        case "st": { e.relayNote = MbRelay.diag; e.linkTimeout(now); String st = e.state(now); String m = Build.MANUFACTURER + " " + Build.MODEL; int k = st.lastIndexOf('}'); return k < 0 ? st : st.substring(0, k) + ",\"self\":" + Codec.q(m) + "}"; }
        case "link": { String r = e.link(a[0], Build.MANUFACTURER + " " + Build.MODEL, now); if (!r.isEmpty()) return r;
          boolean sent = MbHub.toAurum(MainActivity.this, "LINK", "{\"type\":\"LINK\",\"device\":" + Codec.q(Build.MANUFACTURER + " " + Build.MODEL) + "}", MbCode.clean(a[0]));
          if (!sent) { e.linkAck(a[0], false, "Não consegui falar com a Aurum.", now); return "ERR:Não consegui falar com a Aurum."; }
          return ""; }
        case "unlink": e.unlink(now); return "";
        case "set": { boolean v = a[1].equals("1"); if (a[0].equals("on")) e.setOn(v); else if (a[0].equals("cf")) e.setCf(v); else if (a[0].equals("sc")) { e.setSc(v); runOnUiThread(MainActivity.this::screen); } return ""; }
        case "sim.save": e.saveSim(Codec.i(a[0], 1), a[1], Codec.l(a[2], 0), a[3], a[4], a[5], now); return "";
        case "sim.ussdc": e.setCredUssd(Codec.i(a[0], 1), a[1], now); return "";
        case "sim.stc": e.setCredState(Codec.i(a[0], 1), a[1], now); return "";
        case "tab.add": return e.addTab(a[0], now);
        case "tab.sel": e.selTab(a[0]); return "";
        case "tab.del": e.delTab(a[0]); return "";
        case "tab.ren": e.renameTab(a[0], a[1]); return "";
        case "tab.grp": e.setTabGroups(a[0], a[1]); return "";
        case "pay.tab": return MbPay.requestTab(MainActivity.this, Codec.i(a[0], 0), a.length > 1 ? a[1] : "");
        case "sim.cb": e.setCredBal(Codec.i(a[0], 1), a[1].trim().isEmpty() ? -1 : Codec.l(a[1].trim(), -1), now); return "";
        case "sim.st": e.setSimState(Codec.i(a[0], 1), a[1], now); return "";
        case "price.save": {
          String[][] rows = new String[MbCode.MAX_SLOTS][]; for (int i = 0; i < rows.length; i++) rows[i] = new String[]{"", "", ""};
          if (a.length > 0 && !a[0].isEmpty()) { String[] rs = a[0].split(";", -1); for (int i = 0; i < rs.length && i < rows.length; i++) { String[] f = rs[i].split(",", -1); for (int k = 0; k < 3 && k < f.length; k++) rows[i][k] = f[k]; } }
          java.util.List<String> bad = e.savePrices(rows, now); return bad.isEmpty() ? "" : "ERR:" + bad.size() + " linhas com erro. Veja o Painel de erros.";
        }
        case "cprice.save": {
          String[][] rows = new String[MbEngine.CRED_ROWS][]; for (int i = 0; i < rows.length; i++) rows[i] = new String[]{"", "", ""};
          if (a.length > 0 && !a[0].isEmpty()) { String[] rs = a[0].split(";", -1); for (int i = 0; i < rs.length && i < rows.length; i++) { String[] f = rs[i].split(",", -1); for (int k = 0; k < 3 && k < f.length; k++) rows[i][k] = f[k]; } }
          java.util.List<String> bad = e.saveCredPrices(rows, now); if (a.length > 1) e.setCredUssd(1, a[1], now); MbService.start(MainActivity.this);
          return bad.isEmpty() ? "" : "ERR:" + bad.size() + " linhas com erro. Veja o Painel de erros.";
        }
        case "order.edit": { String r = e.editOrder(a[0], a[1], Codec.l(a[2], 0), now); MbService.start(MainActivity.this); return r; }
        case "order.cancel": return e.cancelOrder(a[0], now);
        case "order.done": return e.markDone(a[0], now);
        case "order.reg": return e.register(a[0], Codec.l(a[1], 0), Codec.l(a[2], 0), false, now);
        case "tel.add": return e.addTel(a[0], now);
        case "tel.tog": e.toggleTel(a[0]); return "";
        case "redeem": return e.redeem(a[0], now);
        case "pay.req": return MbPay.request(MainActivity.this, Codec.i(a[0], 0), a.length > 1 ? a[1] : "");
        case "acc": return MbPay.acc(MainActivity.this);
        case "acc.new": return MbPay.account(MainActivity.this, false, a[0], a[1], a[2], e.end <= 0);
        case "acc.rec": return MbPay.account(MainActivity.this, true, "", a[0], a[1], false);
        case "pay.st": return MbPay.state(MainActivity.this);
        case "pay.clr": MbPay.clear(MainActivity.this); return "";
        case "order.manual": { String r = e.submit("M" + now, a[0], Codec.l(a[1], 0), Codec.l(a[2], 0), false, now); MbService.start(MainActivity.this); return r; }
        case "order.ok": e.confirmOrder(a[0], a[1].equals("1"), now); return "";
        case "err.clear": e.clearErrs(); return "";
        case "perms": return perms();
        case "ask": runOnUiThread(MainActivity.this::ask); return "";
        case "battery": runOnUiThread(() -> { if (Build.VERSION.SDK_INT < 23) return; try { startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))); } catch (Exception x) { } }); return "";
        case "accset": runOnUiThread(() -> { try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); } catch (Exception x) { } }); return "";
        case "simsinfo": return UssdRunner.info(MainActivity.this);
        case "copy": runOnUiThread(() -> { ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("erros", a[0])); Toast.makeText(MainActivity.this, "Copiado", Toast.LENGTH_SHORT).show(); }); return "";
        case "ver": return "1.8.1";
        default: return "ERR:operação desconhecida";
      }
    }
  }
}
