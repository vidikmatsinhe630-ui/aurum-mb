package com.vidik.aurummb;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.*;
import java.net.*;
import org.json.*;

/** Compra de um pacote por e-Mola. O cliente cola o ID da transação; o servidor da Aurum junta-o ao SMS que a Sexta-feira (do dono)
 *  leu e ativa os dias na conta da Aurum MB. Esta classe cria a conta no servidor (nome e número), faz o pedido e espera pela resposta. */
final class MbPay {
  private MbPay() { }
  private static boolean running;
  private static SharedPreferences sp(Context c) { return c.getSharedPreferences("aurummb", 0); }

  /** "" (nada), "wait|texto", "ok|texto", "low|texto" ou "nf|texto" */
  static String state(Context c) { return sp(c).getString("pay_st", ""); }
  static void clear(Context c) { sp(c).edit().remove("pay_st").remove("pay_oid").remove("pay_id").remove("pay_idx").remove("pay_at").apply(); }
  private static void set(Context c, String st) { sp(c).edit().putString("pay_st", st).apply(); MbHub.notifyUi(); }
  static boolean hasAccount(Context c) { return !sp(c).getString("mbtok", "").isEmpty(); }

  /** o ID do e-Mola: PP + 6 números, ponto, 4 números, ponto, 6 letras ou números */
  static String normId(String raw) { String u = raw == null ? "" : raw.toUpperCase(java.util.Locale.ROOT).replaceAll("[^A-Z0-9.]", ""); return u; }
  static boolean idOk(String id) { return id.matches("PP\\d{6}\\.\\d{4}\\.[A-Z0-9]{6}"); }

  /** valida e inicia o pedido; devolve "" ou "ERR:motivo" */
  static String request(Context c, int days, String raw, String name, String phone) {
    int idx = -1; for (int i = 0; i < MbCode.PKG.length; i++) if (MbCode.PKG[i][0] == days) idx = i;
    if (idx < 0) return "ERR:Pacote inválido.";
    String id = normId(raw);
    if (!idOk(id)) return "ERR:O ID parece incompleto. Copie-o do SMS do e-Mola, por exemplo PP261027.1029.H97116.";
    if (!hasAccount(c)) {
      String nm = name == null ? "" : name.trim(), ph = phone == null ? "" : phone.replaceAll("\\D", "");
      if (nm.length() < 2) return "ERR:Escreva o seu nome.";
      if (ph.startsWith("258") && ph.length() == 12) ph = ph.substring(3);
      if (!ph.matches("8[2-7]\\d{7}")) return "ERR:Escreva o seu número de telemóvel, por exemplo 84 123 4567.";
      sp(c).edit().putString("mb_name", nm).putString("mb_phone", ph).apply();
    }
    sp(c).edit().remove("pay_oid").putString("pay_id", id).putInt("pay_idx", idx).putLong("pay_at", System.currentTimeMillis()).putString("pay_st", "wait|A procurar o seu pagamento...").apply();
    resume(c); return "";
  }

  static synchronized void resume(final Context c0) {
    final Context c = c0.getApplicationContext();
    if (running || !state(c).startsWith("wait")) return; running = true;
    Thread t = new Thread(() -> {
      try {
        while (state(c).startsWith("wait")) {
          long now = System.currentTimeMillis(), at = sp(c).getLong("pay_at", now);
          if (now - at > 26 * 3600_000L) { set(c, "nf|Não encontrei este pagamento. Confirme o ID ou fale com o suporte."); break; }
          try { if (step(c)) break; } catch (Throwable x) { }
          try { Thread.sleep(now - at < 180_000L ? 3000 : 15000); } catch (Exception x) { }
        }
      } finally { running = false; }
    }, "mbpay"); t.setDaemon(true); t.start();
  }

  /** um passo: cria conta se falta, faz o pedido se falta, vê o estado. true = terminou */
  private static boolean step(Context c) throws Exception {
    if (!hasAccount(c)) {
      JSONObject r = call(c, "POST", "/mb/register", new JSONObject().put("name", sp(c).getString("mb_name", "")).put("phone", sp(c).getString("mb_phone", "")).put("dev", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL).toString(), false);
      if (r.has("error")) { set(c, "nf|" + r.optString("error")); return true; }
      sp(c).edit().putString("mbtok", r.optString("token")).apply();
    }
    long oid = sp(c).getLong("pay_oid", 0);
    if (oid == 0) {
      JSONObject r = call(c, "POST", "/mb/pedido", new JSONObject().put("pack", sp(c).getInt("pay_idx", 0)).put("txid", sp(c).getString("pay_id", "")).toString(), true);
      if (r.has("error")) { String e = r.optString("error"); if (r.optInt("_code") == 401) { sp(c).edit().remove("mbtok").apply(); return false; } set(c, "nf|" + e); return true; }
      JSONObject p = r.optJSONObject("pedido"); if (p == null) return false;
      oid = p.optLong("id"); sp(c).edit().putLong("pay_oid", oid).apply();
      return verdict(c, p);
    }
    JSONObject r = call(c, "GET", "/mb/pedido/estado?id=" + oid, null, true);
    JSONObject p = r.optJSONObject("pedido"); if (p == null) return false;
    return verdict(c, p);
  }

  private static boolean verdict(Context c, JSONObject p) throws Exception {
    String s = p.optString("status");
    if (s.equals("confirmado")) {
      JSONObject me = call(c, "GET", "/mb/me", null, true);
      boolean ok = MbHub.get(c).applyServer(me.optLong("expires"), me.optLong("now", System.currentTimeMillis()), System.currentTimeMillis());
      MbService.start(c);
      set(c, "ok|Pagamento confirmado. O seu pacote já está ativo."); return true;
    }
    if (s.equals("menos")) { set(c, "low|Pagou " + trim(p.optDouble("pago")) + " MT, mas este pacote custa " + trim(p.optDouble("preco")) + " MT. Fale com o suporte para acertar a diferença."); return true; }
    if (s.equals("recusado") || s.equals("expirado")) { set(c, "nf|Não encontrei este pagamento. Confirme o ID ou fale com o suporte."); return true; }
    return false;
  }
  private static String trim(double v) { return v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v); }

  /** pedido ao servidor; devolve sempre um objeto (com "error" e "_code" se falhar) */
  private static JSONObject call(Context c, String method, String path, String body, boolean auth) throws Exception {
    HttpURLConnection h = (HttpURLConnection) new URL(MbRelay.BASE + path).openConnection();
    h.setRequestMethod(method); h.setConnectTimeout(8000); h.setReadTimeout(20000); h.setRequestProperty("Content-Type", "application/json");
    if (auth) h.setRequestProperty("Authorization", "Bearer " + sp(c).getString("mbtok", ""));
    if (body != null) { h.setDoOutput(true); h.getOutputStream().write(body.getBytes("UTF-8")); }
    int code = h.getResponseCode(); InputStream in = code >= 400 ? h.getErrorStream() : h.getInputStream();
    ByteArrayOutputStream o = new ByteArrayOutputStream(); if (in != null) { byte[] b = new byte[4096]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); } h.disconnect();
    JSONObject j; try { j = new JSONObject(o.toString("UTF-8")); } catch (Exception e) { j = new JSONObject(); }
    if (code >= 400) { if (!j.has("error")) j.put("error", "Erro " + code); j.put("_code", code); }
    return j;
  }
}
