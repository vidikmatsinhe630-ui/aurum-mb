package com.vidik.aurummb;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.*;
import java.net.*;
import org.json.*;

/** Compra de um pacote por e-Mola. O cliente cola o ID da transação; esta classe pede à Aurum do dono (pela caixa de correio do servidor)
 *  que confirme o pagamento e recebe de volta um código de ativação, que ativa sozinha. Nada do ID aparece na caixa pública, só um selo (hash). */
final class MbPay {
  private MbPay() { }
  static final String DESK = "MB-PAGA-DESK";
  private static boolean running;
  private static SharedPreferences sp(Context c) { return c.getSharedPreferences("aurummb", 0); }

  /** "" (nada), "wait|texto", "ok|texto", "low|texto" ou "nf|texto" */
  static String state(Context c) { return sp(c).getString("pay_st", ""); }
  static void clear(Context c) { sp(c).edit().remove("pay_st").remove("pay_id").remove("pay_days").remove("pay_at").remove("pay_after").remove("pay_post").apply(); }
  private static void set(Context c, String st) { sp(c).edit().putString("pay_st", st).apply(); MbHub.notifyUi(); }

  /** valida e pede a confirmação; devolve "" ou "ERR:motivo" */
  static String request(Context c, int days, String raw) {
    if (MbCode.price(days) < 0) return "ERR:Pacote inválido.";
    String n = MbCode.norm(raw);
    if (!MbCode.idOk(n)) return "ERR:O código da transação parece incompleto. Copie-o do SMS do e-Mola (o ID, que começa por PP).";
    sp(c).edit().putString("pay_id", n).putInt("pay_days", days).putLong("pay_at", System.currentTimeMillis()).putLong("pay_after", 0).putLong("pay_post", 0).putString("pay_st", "wait|A procurar o seu pagamento...").apply();
    resume(c); return "";
  }

  static synchronized void resume(final Context c0) {
    final Context c = c0.getApplicationContext();
    if (running || !state(c).startsWith("wait")) return; running = true;
    Thread t = new Thread(() -> {
      try {
        while (state(c).startsWith("wait")) {
          long now = System.currentTimeMillis(), at = sp(c).getLong("pay_at", now);
          if (now - at > 25 * 3600_000L) { set(c, "nf|Não encontrei este pagamento. Confirme o código ou fale com o suporte."); break; }
          try { if (now - sp(c).getLong("pay_post", 0) > 300_000L) { post(c); sp(c).edit().putLong("pay_post", now).apply(); } poll(c); } catch (Throwable x) { }
          try { Thread.sleep(now - at < 180_000L ? 3000 : 15000); } catch (Exception x) { }
        }
      } finally { running = false; }
    }, "mbpay"); t.setDaemon(true); t.start();
  }

  private static void post(Context c) throws Exception {
    String id = sp(c).getString("pay_id", ""); int d = sp(c).getInt("pay_days", 0);
    JSONObject j = new JSONObject().put("h", MbCode.payHash(id)).put("d", d);
    HttpURLConnection h = (HttpURLConnection) new URL(MbRelay.BASE + "/relay/put").openConnection();
    h.setRequestMethod("POST"); h.setConnectTimeout(8000); h.setReadTimeout(15000); h.setDoOutput(true); h.setRequestProperty("Content-Type", "application/json");
    JSONObject b = new JSONObject().put("code", DESK).put("dir", "m2a").put("type", "PAY").put("json", j.toString());
    h.getOutputStream().write(b.toString().getBytes("UTF-8")); h.getResponseCode(); h.disconnect();
  }

  private static void poll(Context c) throws Exception {
    String id = sp(c).getString("pay_id", ""); long after = sp(c).getLong("pay_after", 0);
    HttpURLConnection h = (HttpURLConnection) new URL(MbRelay.BASE + "/relay/get?dir=a2m&code=" + URLEncoder.encode(MbCode.payReply(id), "UTF-8") + "&after=" + after).openConnection();
    h.setConnectTimeout(8000); h.setReadTimeout(15000);
    if (h.getResponseCode() != 200) { h.disconnect(); return; }
    ByteArrayOutputStream o = new ByteArrayOutputStream(); InputStream in = h.getInputStream(); byte[] b = new byte[4096]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); h.disconnect();
    JSONArray a = new JSONObject(o.toString("UTF-8")).optJSONArray("msgs"); if (a == null) return;
    for (int i = 0; i < a.length(); i++) {
      JSONObject m = a.getJSONObject(i); long mid = m.optLong("id"); String type = m.optString("type"); JSONObject j = new JSONObject(m.optString("json", "{}"));
      sp(c).edit().putLong("pay_after", Math.max(after, mid)).apply();
      if (type.equals("CODE")) {
        String r = MbHub.get(c).redeem(j.optString("code"), System.currentTimeMillis());
        if (r.isEmpty()) { MbService.start(c); set(c, "ok|Pagamento confirmado. O seu pacote já está ativo."); return; }
        if (r.contains("já foi usado")) { set(c, "ok|Este pagamento já foi ativado antes."); return; }
        set(c, "nf|" + r.replaceFirst("^ERR:", "")); return;
      }
      if (type.equals("LOW")) { set(c, "low|Pagou " + j.optInt("got") + " MT, mas este pacote custa " + j.optInt("need") + " MT. Fale com o suporte para acertar a diferença."); return; }
      if (type.equals("NF")) { set(c, "nf|Não encontrei este pagamento. Confirme o código ou fale com o suporte."); return; }
    }
  }
}
