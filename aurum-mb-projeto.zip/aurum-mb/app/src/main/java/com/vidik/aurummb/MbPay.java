package com.vidik.aurummb;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.*;
import java.net.*;
import org.json.*;

/** Compra de um pacote por e-Mola. O cliente cola o ID da transação; o servidor da Aurum junta-o ao SMS que a Sexta-feira (do dono)
 *  leu e ativa os dias na conta da Aurum MB. Esta classe cria a conta no servidor (nome e número), faz o pedido e espera pela resposta. */
final class MbPay {
  private MbPay() { }
  private static boolean running;
  private static SharedPreferences sp(Context c) { return c.getSharedPreferences("aurummb", 0); }

  /** "" (nada), "wait|texto", "ok|texto", "low|texto" ou "nf|texto" */
  static String state(Context c) { return sp(c).getString("pay_st", ""); }
  static void clear(Context c) { sp(c).edit().remove("pay_st").remove("pay_oid").remove("pay_id").remove("pay_idx").remove("pay_kind").remove("pay_at").apply(); }
  private static void set(Context c, String st) { sp(c).edit().putString("pay_st", st).apply(); MbHub.notifyUi(); }
  static boolean hasAccount(Context c) { return !sp(c).getString("mbtok", "").isEmpty(); }

  /** o ID do e-Mola: PP + 6 números, ponto, 4 números, ponto, 6 letras ou números */
  static String normId(String raw) { String u = raw == null ? "" : raw.toUpperCase(java.util.Locale.ROOT).replaceAll("[^A-Z0-9.]", ""); return u; }
  static boolean idOk(String id) { return id.matches("PP\\d{6}\\.\\d{4}\\.[A-Z0-9]{6}"); }

  /** valida e inicia o pedido; devolve "" ou "ERR:motivo". A conta já tem de existir. */
  static String request(Context c, int days, String raw) {
    int idx = -1; for (int i = 0; i < MbCode.PKG.length; i++) if (MbCode.PKG[i][0] == days) idx = i;
    if (idx < 0) return "ERR:Pacote inválido.";
    if (!hasAccount(c)) return "ERR:Crie a sua conta primeiro.";
    String id = normId(raw);
    if (!idOk(id)) return "ERR:O ID parece incompleto. Copie-o do SMS do e-Mola, por exemplo PP261027.1029.H97116.";
    sp(c).edit().remove("pay_oid").remove("pay_kind").putString("pay_id", id).putInt("pay_idx", idx).putLong("pay_at", System.currentTimeMillis()).putString("pay_st", "wait|A procurar o seu pagamento...").apply();
    resume(c); return "";
  }

  /** compra de tabelas extra: idx = 0..3 na lista do servidor (1, 2, 3 ou 5 tabelas) */
  static String requestTab(Context c, int idx, String raw) {
    if (idx < 0 || idx >= TABQ.length) return "ERR:Escolha quantas tabelas quer.";
    if (!hasAccount(c)) return "ERR:Crie a sua conta primeiro.";
    String id = normId(raw);
    if (!idOk(id)) return "ERR:O ID parece incompleto. Copie-o do SMS do e-Mola, por exemplo PP261027.1029.H97116.";
    sp(c).edit().remove("pay_oid").putString("pay_id", id).putInt("pay_idx", idx).putString("pay_kind", "mbtab").putLong("pay_at", System.currentTimeMillis()).putString("pay_st", "wait|A procurar o seu pagamento...").apply();
    resume(c); return "";
  }
  static final int[] TABQ = {1, 2, 3, 5};
  /** desbloqueio da tabela semanal (25 MT), pago como as tabelas extra */
  static String requestSem(Context c, String raw) {
    if (!hasAccount(c)) return "ERR:Crie a sua conta primeiro.";
    String id = normId(raw);
    if (!idOk(id)) return "ERR:O ID parece incompleto. Copie-o do SMS do e-Mola, por exemplo PP261027.1029.H97116.";
    sp(c).edit().remove("pay_oid").putString("pay_id", id).putInt("pay_idx", 0).putString("pay_kind", "mbsem").putLong("pay_at", System.currentTimeMillis()).putString("pay_st", "wait|A procurar o seu pagamento...").apply();
    resume(c); return "";
  }
  /** {"has":bool,"name":"","phone":"","email":"","fresh":bool}; fresh = nunca teve pacote (tem direito aos 3 dias grátis) */
  static String acc(Context c) {
    SharedPreferences p = sp(c);
    return "{\"has\":" + hasAccount(c) + ",\"name\":" + Codec.q(p.getString("mb_name", "")) + ",\"phone\":" + Codec.q(p.getString("mb_phone", "")) + ",\"email\":" + Codec.q(p.getString("mb_email", "")) + "}";
  }
  static String cleanPhone(String raw) { String ph = raw == null ? "" : raw.replaceAll("\\D", ""); if (ph.startsWith("258") && ph.length() == 12) ph = ph.substring(3); return ph; }
  static boolean emailOk(String e) { return e != null && e.matches("[^\\s@]{1,64}@[^\\s@]{1,190}\\.[^\\s@]{2,}") && e.length() <= 120; }

  /** cria a conta no servidor (e dá os 3 dias grátis se esta instalação nunca teve pacote) ou recupera uma existente. "" ou "ERR:motivo" */
  static String account(Context c, boolean recover, String name, String email, String phone, boolean fresh) {
    String nm = name == null ? "" : name.trim(), em = email == null ? "" : email.trim().toLowerCase(java.util.Locale.ROOT), ph = cleanPhone(phone);
    if (!recover && nm.length() < 2) return "ERR:Escreva o seu nome.";
    if (!emailOk(em)) return "ERR:Escreva um e-mail válido.";
    if (!ph.matches("8[2-7]\\d{7}")) return "ERR:Escreva o seu número de telemóvel, por exemplo 84 123 4567.";
    try {
      JSONObject body = new JSONObject().put("phone", ph).put("email", em);
      if (!recover) body.put("name", nm).put("trial", fresh).put("dev", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);
      JSONObject r = call(c, "POST", recover ? "/mb/recover" : "/mb/register", body.toString(), false);
      if (r.has("error")) return "ERR:" + r.optString("error");
      sp(c).edit().putString("mbtok", r.optString("token")).putString("mb_name", r.optString("name", nm)).putString("mb_phone", ph).putString("mb_email", em).apply();
      applyMe(c, r);
      MbService.start(c); MbHub.notifyUi(); return "";
    } catch (Exception e) { return "ERR:" + NetErr.why(e); }
  }
  private static void applyMe(Context c, JSONObject me) { try { MbHub.get(c).setTabsBought(me.optInt("tabs", 0)); MbHub.get(c).setSem(me.optBoolean("sem", false)); MbHub.get(c).setBlkSrv(me.optBoolean("bloq", false), me.optString("nota", ""));  if (me.has("expires")) MbHub.get(c).syncServer(me.optLong("expires"), me.optLong("now", System.currentTimeMillis()), System.currentTimeMillis()); } catch (Throwable x) { } }
  /** põe os dias da conta em dia com o servidor (pagamentos aprovados, aprovação manual, outro aparelho) */
  static void sync(Context c) {
    if (!hasAccount(c)) return;
    try { JSONObject me = call(c, "GET", "/mb/me?v=" + AppVer.NAME, null, true); if (me.optInt("_code") == 401) { sp(c).edit().remove("mbtok").apply(); MbHub.notifyUi(); return; } if (!me.has("error")) applyMe(c, me); } catch (Throwable x) { }
  }

  static synchronized void resume(final Context c0) {
    final Context c = c0.getApplicationContext();
    if (running || !state(c).startsWith("wait")) return; running = true;
    Thread t = new Thread(() -> {
      try {
        while (state(c).startsWith("wait")) {
          long now = System.currentTimeMillis(), at = sp(c).getLong("pay_at", now);
          if (now - at > 26 * 3600_000L) { set(c, "nf|Não encontrei este pagamento. Confirme o ID ou fale com o suporte."); break; }
          try { if (step(c)) break; } catch (Throwable x) { }
          try { Thread.sleep(now - at < 180_000L ? 3000 : 15000); } catch (Exception x) { }
        }
      } finally { running = false; }
    }, "mbpay"); t.setDaemon(true); t.start();
  }

  /** um passo: cria conta se falta, faz o pedido se falta, vê o estado. true = terminou */
  private static boolean step(Context c) throws Exception {
    if (!hasAccount(c)) { set(c, "nf|Entre na sua conta para continuar."); return true; }
    long oid = sp(c).getLong("pay_oid", 0);
    if (oid == 0) {
      JSONObject r = call(c, "POST", "/mb/pedido", new JSONObject().put("pack", sp(c).getInt("pay_idx", 0)).put("kind", sp(c).getString("pay_kind", "")).put("txid", sp(c).getString("pay_id", "")).toString(), true);
      if (r.has("error")) { String e = r.optString("error"); if (r.optInt("_code") == 401) { sp(c).edit().remove("mbtok").apply(); set(c, "nf|A sessão terminou. Recupere a conta com o seu número e e-mail."); return true; } set(c, "nf|" + e); return true; }
      JSONObject p = r.optJSONObject("pedido"); if (p == null) return false;
      oid = p.optLong("id"); sp(c).edit().putLong("pay_oid", oid).apply();
      return verdict(c, p);
    }
    JSONObject r = call(c, "GET", "/mb/pedido/estado?id=" + oid, null, true);
    JSONObject p = r.optJSONObject("pedido"); if (p == null) return false;
    return verdict(c, p);
  }

  private static boolean verdict(Context c, JSONObject p) throws Exception {
    String s = p.optString("status");
    if (s.equals("confirmado")) {
      JSONObject me = call(c, "GET", "/mb/me", null, true);
      boolean ok = MbHub.get(c).applyServer(me.optLong("expires"), me.optLong("now", System.currentTimeMillis()), System.currentTimeMillis());
      MbService.start(c);
      MbHub.get(c).setTabsBought(me.optInt("tabs", 0)); MbHub.get(c).setSem(me.optBoolean("sem", false));
      String pk = sp(c).getString("pay_kind", "");
      set(c, pk.equals("mbsem") ? "ok|Pagamento confirmado. A tabela semanal está desbloqueada." : pk.equals("mbtab") ? "ok|Pagamento confirmado. A tabela nova já pode ser usada." : "ok|Pagamento confirmado. O seu pacote já está ativo."); return true;
    }
    if (s.equals("menos")) { set(c, "low|Pagou " + trim(p.optDouble("pago")) + " MT, mas este pacote custa " + trim(p.optDouble("preco")) + " MT. Fale com o suporte para acertar a diferença."); return true; }
    if (s.equals("recusado") || s.equals("expirado")) { set(c, "nf|Não encontrei este pagamento. Confirme o ID ou fale com o suporte."); return true; }
    return false;
  }
  private static String trim(double v) { return v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v); }

  /** pedido ao servidor; devolve sempre um objeto (com "error" e "_code" se falhar) */
  private static JSONObject call(Context c, String method, String path, String body, boolean auth) throws Exception {
    HttpURLConnection h = NetErr.open(MbRelay.BASE + path);
    h.setRequestMethod(method); h.setConnectTimeout(8000); h.setReadTimeout(20000); h.setRequestProperty("Content-Type", "application/json");
    if (auth) h.setRequestProperty("Authorization", "Bearer " + sp(c).getString("mbtok", ""));
    if (body != null) { h.setDoOutput(true); h.getOutputStream().write(body.getBytes("UTF-8")); }
    int code = h.getResponseCode(); InputStream in = code >= 400 ? h.getErrorStream() : h.getInputStream();
    ByteArrayOutputStream o = new ByteArrayOutputStream(); if (in != null) { byte[] b = new byte[4096]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); } h.disconnect();
    JSONObject j; try { j = new JSONObject(o.toString("UTF-8")); } catch (Exception e) { j = new JSONObject(); }
    if (code >= 400) { if (!j.has("error")) j.put("error", "Erro " + code); j.put("_code", code); }
    return j;
  }
}
