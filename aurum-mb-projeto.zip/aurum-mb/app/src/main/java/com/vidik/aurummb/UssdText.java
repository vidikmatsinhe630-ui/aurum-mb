package com.vidik.aurummb;

/** Conferências puras sobre o que o telefone mostra no USSD (testadas sem Android). */
final class UssdText {
  private UssdText() { }
  static final String[] KNOWN = {"phone", "telecom", "dialer", "incallui", "huawei", "samsung", "miui", "xiaomi", "oppo", "coloros", "vivo", "transsion", "tecno", "infinix", "itel", "realme", "oneplus", "motorola", "lenovo"};
  static boolean known(String pkg) { pkg = pkg == null ? "" : pkg.toLowerCase(); if (pkg.equals("com.vidik.aurummb") || pkg.contains("systemui") || pkg.contains("launcher") || pkg.contains("whatsapp") || pkg.contains("chrome") || pkg.contains("inputmethod") || pkg.contains("keyboard")) return false; for (String k : KNOWN) if (pkg.contains(k)) return true; return false; }
  /** texto que o telefone mostra enquanto espera pela operadora: não é uma resposta, é para esperar */
  static boolean loading(String msg, boolean hasEdit) {
    if (hasEdit) return false;
    String low = msg.toLowerCase(java.util.Locale.ROOT);
    if (low.length() > 90) return false;
    for (String k : new String[]{"em execu", "a executar", "executando", "execut", "running", "ussd code", "c\u00f3digo ussd", "codigo ussd", "aguarde", "please wait", "carregando", "a carregar", "loading", "a processar", "processing", "ligando", "a ligar", "connecting"}) if (low.contains(k)) return true;
    return false;
  }
}
