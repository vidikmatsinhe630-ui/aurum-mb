package com.vidik.aurummb;

/** Conferências puras sobre o que o telefone mostra no USSD (testadas sem Android). */
final class UssdText {
  private UssdText() { }
  static final String[] KNOWN = {"phone", "telecom", "dialer", "incallui", "huawei", "samsung", "miui", "xiaomi", "oppo", "coloros", "vivo", "transsion", "tecno", "infinix", "itel", "realme", "oneplus", "motorola", "lenovo"};
  static boolean known(String pkg) { pkg = pkg == null ? "" : pkg.toLowerCase(); if (pkg.equals("com.vidik.aurummb") || pkg.contains("systemui") || pkg.contains("launcher") || pkg.contains("whatsapp") || pkg.contains("chrome") || pkg.contains("inputmethod") || pkg.contains("keyboard")) return false; for (String k : KNOWN) if (pkg.contains(k)) return true; return false; }
  /** pacote que não é do telefone mas pode ser a janela do USSD (alguns fabricantes): exclui a própria app, teclados, ecrã inicial e apps de conversa */
  static boolean foreign(String pkg) { pkg = pkg == null ? "" : pkg.toLowerCase(); if (pkg.isEmpty() || pkg.equals("null") || pkg.equals("com.vidik.aurummb") || pkg.contains("systemui") || pkg.contains("launcher") || pkg.contains("whatsapp") || pkg.contains("chrome") || pkg.contains("inputmethod") || pkg.contains("keyboard") || pkg.contains("gboard") || pkg.contains("swiftkey")) return false; return true; }
  /** texto que o telefone mostra enquanto espera pela operadora: não é uma resposta, é para esperar */
  static boolean loading(String msg, boolean hasEdit) {
    if (hasEdit) return false;
    String low = java.text.Normalizer.normalize(msg.toLowerCase(java.util.Locale.ROOT), java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "").replace("\u2026", "...").trim();   // sem acentos: "Exécution" = "execution"
    if (low.length() > 90) return false;
    for (String k : new String[]{"execution", "ejecut", "chargement", "en cours", "patient", "veuillez", "espere", "cargando", "wird ausgef", "bitte warten", "yurutul", "mohon tunggu", "sedang"}) if (low.contains(k)) return true;
    if (low.length() < 60 && low.endsWith("...") && (low.contains("ussd") || low.contains("code") || low.contains("codigo"))) return true;
    for (String k : new String[]{"em execu", "a executar", "executando", "execut", "running", "ussd code", "c\u00f3digo ussd", "codigo ussd", "aguarde", "please wait", "carregando", "a carregar", "loading", "a processar", "processing", "ligando", "a ligar", "connecting"}) if (low.contains(k)) return true;
    return false;
  }
  /** mensagem que já é uma recusa/erro da operadora (não vale a pena carregar em OK para continuar) */
  static boolean midError(String msg) {
    String low = java.text.Normalizer.normalize((msg == null ? "" : msg).toLowerCase(java.util.Locale.ROOT), java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    for (String k : new String[]{"invalid", "incorrect", "erro", "error", "falh", "nao foi possivel", "nao e possivel", "insuficiente", "insufficient", "indisponivel", "unavailable", "tente mais tarde", "try again", "nao autorizado", "recusad", "denied", "limite", "excedeu", "exceeded", "bloquead", "nao tem", "nao possui", "sem saldo", "mbno invalido", "numero invalido", "erreur", "invalide", "impossible", "insuffisant", "refuse", "echec", "indisponible"}) if (low.contains(k)) return true;
    return false;
  }
  /** botões que só continuam a conversa (não fecham): "OK", "Enviar", "Seguinte", "Continuar", "Confirmar", "Sim" */
  static boolean continueLabel(String t) {
    t = t == null ? "" : t.trim().toLowerCase(java.util.Locale.ROOT);
    for (String k : new String[]{"ok", "enviar", "send", "seguinte", "next", "continuar", "continue", "confirmar", "confirm", "sim", "yes", "responder", "reply", "envoyer", "valider", "suivant", "continuer", "confirmer", "oui", "repondre", "enviar"}) if (t.equals(k)) return true;
    return false;
  }
  /** rótulos que só podem ser o botão de enviar/continuar (mesmo que o telefone não o marque como clicável) */
  static boolean sendLabel(String t) {
    t = t == null ? "" : t.trim().toLowerCase(java.util.Locale.ROOT);
    for (String k : new String[]{"enviar", "send", "responder", "reply", "ok", "seguinte", "next", "continuar", "continue", "confirmar", "confirm", "envoyer", "valider", "suivant", "continuer", "confirmer", "repondre"}) if (t.equals(k)) return true;
    return false;
  }
  /** botão que cancela/fecha (nunca é o de enviar), em português, inglês, francês e espanhol */
  static boolean cancelLabel(String t) {
    t = java.text.Normalizer.normalize(t == null ? "" : t.trim().toLowerCase(java.util.Locale.ROOT), java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    for (String k : new String[]{"cancel", "annul", "anular", "fechar", "close", "fermer", "cerrar", "dismiss", "dispensar", "abbrech", "non", "no", "nao", "voltar", "retour", "back"}) if (t.equals(k) || (k.length() > 3 && t.contains(k))) return true;
    return false;
  }
}
