package com.vidik.aurummb;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;

/** Liga o núcleo ao Android: armazenamento, USSD e avisos à Aurum. Um só motor para a app inteira. */
final class MbHub {
  static final String AURUM_PKG = "com.vidik.aurum", PERM = "com.vidik.aurummb.permission.LINK";
  interface Ui { void changed(); }
  static volatile Ui ui;
  private static MbEngine eng;

  static synchronized MbEngine get(Context c) {
    if (eng != null) return eng;
    final Context app = c.getApplicationContext();
    final SharedPreferences sp = app.getSharedPreferences("aurummb", 0);
    eng = new MbEngine(new MbEngine.KV() {
      public String get(String k, String d) { return sp.getString(k, d); }
      public void set(String k, String v) { sp.edit().putString(k, v).apply(); }
    }, new UssdRunner(app), new MbEngine.Out() {
      public boolean aurum(String type, String json) { return toAurum(app, type, json); }
      public void changed() { Ui u = ui; if (u != null) u.changed(); }
    });
    return eng;
  }

  /** manda o aviso à Aurum (mesma assinatura da app). Devolve true se a Aurum está instalada e o aviso saiu. */
  static boolean toAurum(Context c, String type, String json) {
    try {
      c.getPackageManager().getPackageInfo(AURUM_PKG, 0);
      Intent i = new Intent("com.vidik.aurummb.EVENT").setPackage(AURUM_PKG).putExtra("type", type).putExtra("json", json).putExtra("code", get(c).linkCode);
      c.sendBroadcast(i, PERM); return true;
    } catch (PackageManager.NameNotFoundException e) { return false; } catch (Exception e) { return false; }
  }
  static void notifyUi() { Ui u = ui; if (u != null) u.changed(); }
}
