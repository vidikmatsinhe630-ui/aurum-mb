package com.vidik.aurummb;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;

/** Liga o núcleo ao Android: armazenamento, USSD e avisos à Aurum. Um só motor para a app inteira. */
final class MbHub {
  static final String AURUM_PKG = "com.vidik.aurum", PERM = "com.vidik.aurummb.permission.LINK";
  interface Ui { void changed(); }
  static volatile Ui ui;
  private static MbEngine eng;

  static synchronized MbEngine get(Context c) {
    if (eng != null) return eng;
    final Context app = c.getApplicationContext();
    final SharedPreferences sp = app.getSharedPreferences("aurummb", 0); MbRelay.start(app);
    eng = new MbEngine(new MbEngine.KV() {
      public String get(String k, String d) { return sp.getString(k, d); }
      public void set(String k, String v) { sp.edit().putString(k, v).apply(); }
    }, new UssdRunner(app), new MbEngine.Out() {
      public boolean aurum(String type, String json) { return toAurum(app, type, json); }
      public void changed() { dirty = true; Ui u = ui; if (u != null) u.changed(); }
    });
    return eng;
  }

  /** manda o aviso à Aurum (mesma assinatura da app). Devolve true se a Aurum está instalada e o aviso saiu. */
  static boolean toAurum(Context c, String type, String json) { return toAurum(c, type, json, get(c).linkCode); }
  static boolean toAurum(Context c, String type, String json, String code) {
    MbRelay.post(code, type, json);
    try {
      c.getPackageManager().getPackageInfo(AURUM_PKG, 0);
      Intent i = new Intent("com.vidik.aurummb.EVENT").setPackage(AURUM_PKG).putExtra("type", type).putExtra("json", json).putExtra("code", code);
      c.sendBroadcast(i, PERM); return true;
    } catch (PackageManager.NameNotFoundException e) { return true; } catch (Exception e) { return true; }   // outro telemóvel: o aviso vai pela internet
  }
  /** o que só o telemóvel sabe: acessibilidade, permissões, bateria */
  static String androidBits(Context c) {
    boolean acc = UssdAccess.enabled(c), call = Perm.has(c, android.Manifest.permission.CALL_PHONE), ph = Perm.has(c, android.Manifest.permission.READ_PHONE_STATE), bat = false;
    bat = Perm.battery(c);
    return "{\"acc\":" + acc + ",\"call\":" + call + ",\"phone\":" + ph + ",\"bat\":" + bat + ",\"v\":\"" + BuildConfigV + "\"}";
  }
  static final String BuildConfigV = "1.9.3";
  static volatile long lastStatus; static volatile boolean dirty = true;
  /** manda o estado à Aurum (no máximo de 15 em 15 s se mudou, e de 60 em 60 s sempre) */
  static void sendStatus(Context c, boolean force) {
    try {
      MbEngine e = get(c); if (!e.linked()) return; long now = System.currentTimeMillis();
      if (!force && !(dirty && now - lastStatus > 15000) && now - lastStatus < 60000) return;
      if (toAurum(c, "STATUS", e.status(now, androidBits(c)), e.linkCode)) { lastStatus = now; dirty = false; }
    } catch (Throwable t) { }
  }
  static void notifyUi() { Ui u = ui; if (u != null) u.changed(); }
}
