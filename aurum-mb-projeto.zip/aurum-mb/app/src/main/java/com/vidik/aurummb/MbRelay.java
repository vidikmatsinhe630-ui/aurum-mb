package com.vidik.aurummb;

import android.content.Context;
import java.io.*;
import java.net.*;
import org.json.*;

/** Ligação à Aurum por internet (a Aurum pode estar noutro telemóvel). Caixa de correio no servidor; o código MB-XXXX-XXXX é o segredo. */
final class MbRelay {
  static final String BASE = "https://aurum-servidor.vidikmatsinhe630.workers.dev";
  private static boolean started; private static volatile long busyAt = System.currentTimeMillis(); static volatile String diag = "";
  static String note(boolean put, int rc, Throwable t) { diag = (put ? "envio " : "leitura ") + (t != null ? "falhou (sem internet ou servidor inacessível)" : rc == 200 ? "ok" : "recusado pelo servidor, código " + rc); return diag; }

  static void post(final String code, final String type, final String json) {
    if (code == null || !MbCode.linkFormat(code)) return;
    new Thread(() -> {
      for (int k = 0; k < 3; k++) {
        try {
          HttpURLConnection h = NetErr.open(BASE + "/relay/put");
          h.setRequestMethod("POST"); h.setConnectTimeout(8000); h.setReadTimeout(15000); h.setDoOutput(true); h.setRequestProperty("Content-Type", "application/json");
          JSONObject b = new JSONObject().put("code", code).put("dir", "m2a").put("type", type).put("json", json);
          h.getOutputStream().write(b.toString().getBytes("UTF-8")); int rc = h.getResponseCode(); h.disconnect(); note(true, rc, null);
          if (rc == 200 || rc == 400 || rc == 429) return;
        } catch (Throwable t) { note(true, 0, t); }
        try { Thread.sleep(3000); } catch (Exception e) { }
      }
    }).start();
  }

  static synchronized void start(final Context c0) {
    if (started) return; started = true; final Context c = c0.getApplicationContext();
    Thread t = new Thread(() -> {
      while (true) {
        long wait = 6000;
        try {
          MbEngine e = MbHub.get(c); String code = e.activeCode();
          if (!code.isEmpty()) {
            poll(c, e, code);
            long idle = System.currentTimeMillis() - busyAt; if (e.pending()) busyAt = System.currentTimeMillis();
            wait = e.pending() ? 2000 : idle < 300000L ? 4000 : 10000;   // parado há mais de 5 min: consulta de 10 em 10 s (poupa pedidos ao servidor)
          }
        } catch (Throwable x) { note(false, 0, x); }
        try { Thread.sleep(wait); } catch (Exception x) { }
      }
    }, "mbrelay"); t.setDaemon(true); t.start();
  }

  private static void poll(Context c, MbEngine e, String code) throws Exception {
    final String ck = "mbr_" + code; final android.content.SharedPreferences sp = c.getSharedPreferences("aurummb", 0);
    long after = Long.parseLong(sp.getString(ck, "0"));
    HttpURLConnection h = NetErr.open(BASE + "/relay/get?dir=a2m&code=" + URLEncoder.encode(code, "UTF-8") + "&after=" + after);
    h.setConnectTimeout(8000); h.setReadTimeout(15000);
    int rc = h.getResponseCode(); note(false, rc, null); if (rc != 200) { h.disconnect(); return; }
    ByteArrayOutputStream o = new ByteArrayOutputStream(); InputStream in = h.getInputStream(); byte[] b = new byte[4096]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); h.disconnect();
    JSONArray a = new JSONObject(o.toString("UTF-8")).optJSONArray("msgs"); if (a == null) return;
    if (a.length() > 0) busyAt = System.currentTimeMillis();
    long top = after;
    for (int i = 0; i < a.length(); i++) {
      JSONObject m = a.getJSONObject(i); long id = m.optLong("id"); String type = m.optString("type");
      try { handle(c, e, code, type, new JSONObject(m.optString("json", "{}"))); } catch (Throwable t) { }
      if (id > top) { top = id; sp.edit().putString(ck, "" + top).apply(); }
    }
  }

  private static void handle(Context c, MbEngine e, String code, String type, JSONObject j) {
    long now = System.currentTimeMillis();
    if (type.equals("ACK")) {
      boolean ok = e.linkAck(code, j.optBoolean("ok", false), j.optString("msg", ""), now);
      if (ok) { MbService.start(c); MbHub.sendStatus(c, true); }
      MbHub.notifyUi();
    } else if (type.equals("CFG")) {
      if (!e.codeOk(code)) return;
      if (j.has("retries")) e.setRetries(j.optInt("retries", 0));
      MbHub.sendStatus(c, true); MbHub.notifyUi();
    } else if (type.equals("ORDER")) {
      if (!e.codeOk(code)) return;
      e.submit(j.optString("id"), j.optString("phone"), j.optLong("mb", 0), j.optLong("mt", 0), false, j.optBoolean("cred", false), j.optString("grp"), j.optString("gname"), j.optBoolean("sem", false), now);
      MbService.start(c); MbHub.notifyUi();
    } else if (type.equals("GROUPS")) {
      if (!e.codeOk(code)) return;
      org.json.JSONArray a = j.optJSONArray("g"); if (a == null) return;
      for (int i = 0; i < a.length(); i++) { org.json.JSONObject o = a.optJSONObject(i); if (o != null) e.learnGroup(o.optString("j"), o.optString("n")); }
      MbHub.notifyUi();
    }
  }
}
