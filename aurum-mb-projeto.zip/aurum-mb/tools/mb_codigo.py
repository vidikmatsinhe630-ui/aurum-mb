#!/usr/bin/env python3
"""Gera códigos de ativação da Aurum MB (provisório, até existir o portal de pagamento).
Uso:  python3 mb_codigo.py pacote 7        (3 = teste grátis, 7, 15, 25, 32 ou 62 dias)
      python3 mb_codigo.py lugares         (mais 10 lugares na tabela, 75 MT)
Dá um código novo cada vez. O SEGREDO tem de ser igual ao de MbCode.SECRET na app."""
import hmac, hashlib, random, sys
SECRET = "aurum-mb-troque-este-segredo"
A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
if len(sys.argv) < 2 or sys.argv[1] not in ("pacote", "lugares"):
    sys.exit(__doc__)
if sys.argv[1] == "pacote":
    kind, n = "PCT", int(sys.argv[2]) if len(sys.argv) > 2 else 0
    if n not in (3, 7, 15, 25, 32, 62): sys.exit("Dias: 3 (teste), 7, 15, 25, 32 ou 62")
else:
    kind, n = "LUG", 10
rn = "".join(random.SystemRandom().choice(A) for _ in range(6))
h = hmac.new(SECRET.encode(), f"{kind}-{n}-{rn}".encode(), hashlib.sha256).digest()
print(f"{kind}-{n}-{rn}-" + "".join(A[b % len(A)] for b in h[:4]))
